<?php
session_start();
include ('connect.php'); 

if(isset($_POST['btnRegister']))
{
	$txtFirstName=$_POST['txtFirstName'];
	$txtLastName=$_POST['txtLastName'];
    $txtEmail=$_POST['txtEmail'];
    $txtPassword=$_POST['txtPassword'];

    $checkCustomer="SELECT * FROM Customer
        Where FirstName='$txtFirstName'";

    $result=mysql_query($checkCustomer);
    $count=mysql_num_rows($result);
    
    if ($count!=0)
    {
        echo "<script>window.alert('FirstName $txtFirstName already exist in Database.')</script>";
        echo "<script>window.location='CustomerRegister.php'</script>";
        exit();
    }

    $query="INSERT INTO `Customer`(`FirstName`,`LastName`,`Email`,`Password`)
    VALUES ('$txtFirstName','$txtLastName','$txtEmail','$txtPassword')";

    $result=mysql_query($query);

    if($result)
    {
        echo "<script>window.alert('Register sucessful')</script>";
        echo "<script>window.location='Login.php'</script>";  
    }
    else
    {
        echo "<p>Something wrong in Customer Register" . mysql_error() . "</p>";
    }
}
?>

<script>
function myFunction()
{
    var txt;
    var person = prompt("Please enter your name:", "Harry Potter");
    if (person == null || person == "") {
        txt = "User cancelled the prompt.";
    } else {
        txt = "Hello " + person + "! How are you today?";
    }
    document.getElementById("demo").innerHTML = txt;
}
</script>

<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css"/>
<style>
html, body 
{   
    width: 100%;   
    height: 100%;   
    font-family: "Helvetica Neue", Helvetica, sans-serif;   
    color: #444;   
    -webkit-font-smoothing: antialiased; background:url(BookI   mages/bookworm.jpg)no-repeat center;
}

#container 
{
    position: fixed;
    width: 340px;
    height: 30px;
    top: 50%;
    left: 50%;
    margin-top: -140px;
    margin-left: -170px;
}

form
{
   margin: 0 auto;
   margin-top: 20px;
}

label 
{
    color: black;
    display: inline-block;
    margin-left: 20px;
    padding-top: 12px;
    font-size: 14px;
}

legend
{
    color:black;
    display: inline-block;
    margin-left: 10px;
    padding-top: 10px;
    font-size: 15px;
}

input 
{
    font-family: "Verdana";
    font-size: 15px;
    outline: none;
}

#lower
{
    background: #9999FF;
    width: 100%;
    height: 80px margin-top: 20px;
}

input[type=submit]
{
    margin-left: 10px;
    margin-bottom: 20px;
    width: 80px;
    height: 30px;

    background: #fff;
    border-radius: 3px;
    border: 1px solid #ccc;
    box-shadow: 0 1px 2px rgba(0, 0, 0, .1);
}

input[type=text]
{
   width:240px;
   height: 25px;
   margin-left: -10px;
   border:1px solid black;
}

input[type=password]
{
   width:240px;
   height: 25px;
   margin-left: -10px;
   border:1px solid black;
}

#container
{
    position: fixed;
    width: 270px;
    height: 260px;
    top: 50%;
    left: 52%;
    margin-top: -140px;
    margin-left: -170px;
    background:#9999FF;
    border-radius: 3px;
    border: 1px solid #ccc;
    box-shadow: 0 1px 2px rgba(0, 0, 0, .1);

    border: 1px solid #bb99ff;
    border-radius: 2px;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 1px black;
}


input[type=submit] 
{
    float: left 20px;
    margin-right: 20px;
    margin-top: -30px;
    width: 110px;
    height: 35px;
    font-size: 11px;
    font-weight: bold;
    color:black;
    background-color: #acd6ef; /*IE fallback*/
    background-image: -webkit-gradient(linear, left top, left bottom, from(#ffff00), to(#ffff00));
    background-image: -moz-linear-gradient(top left 90deg, #acd6ef 0%, #6ec2e8 100%);
    background-image: linear-gradient(top left 90deg, #acd6ef 0%, #6ec2e8 100%);
    border-radius: 5px ;
    border: 1px solid grey;
    box-shadow: 0 1px 2px rgba(0, 0, 0, .3), inset 0 1px 0 rgba(255, 255, 255, .5);
    cursor: pointer;
}

input[type=reset]
{
    width: 107px;
    height: 35px; 
    font-size:11px;
    font-weight: bold;
    border-radius: 5px;
    border: 1px solid grey;
    background-image: -webkit-gradient(linear, left top, left bottom, from(#a6ff4d), to(#a6ff4d));   

}
</style>
</head>

<html>
<form action="CustomerRegister.php" method="post">
<div id="container">
<legend>Register an Account</legend>
    <label>
    <input type="text" name="txtFirstName" placeholder="First Name" required/>
    </label>
    <br/>

    <label>
    <input type="text" name="txtLastName" placeholder="Last Name" required/>
    </label>
    <br/>

    <label>
    <input type="text" name="txtEmail" placeholder="Email" required/>
    </label>
    <br/>

    <label>
    <input type="password" name="txtPassword" placeholder="Password"/>
    </label>
    <br/>

    <div id="lower">
    <br/>
    <input type="submit" name="btnRegister" value="Register"/>
    <input type="reset" value="Cancel"/>
    </div>
</div>
</form>
</body>
</html>


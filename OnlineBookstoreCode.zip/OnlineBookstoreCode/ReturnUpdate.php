<?php  
include('connect.php');

if(isset($_REQUEST['ISBN'])) 
{
	$ISBN=$_REQUEST['ISBN'];

	$query="SELECT * FROM returnbooks WHERE ISBN='$ISBN'";
	$result=mysql_query($query);
	$array=mysql_fetch_array($result);
	
	$ISBN=$array['ISBN'];	
	$Quantity=$array['Quantity'];
	$CustomerID=$array['CustomerID'];
	$CustomerName=$array['CustomerName'];
	$Reason=$array['Reason'];
}
else
{
	$ISBN="";
}

if(isset($_POST['btnUpdate'])) 
{
	$txtISBN=$_POST['txtISBN'];
	$txtQuantity=$_POST['txtQuantity'];
	$txtCustomerID=$_POST['txtCustomerID'];
	$txtCustomerName=$_POST['txtCustomerName'];
	$txtReason=$_POST['txtReason'];

	$query="UPDATE returnbooks
			SET ISBN='$txtISBN',
			Quantity='$txtQuantity',
			CustomerID='$txtCustomerID',
			CustomerName='$txtCustomerName',
			Reason='$txtReason'
			WHERE ISBN='$txtISBN'";

	$result=mysql_query($query);
	
	if($result)
	{
		echo "<script>window.alert('Return Successfully Updated.')</script>";
		echo "<script>window.location='Returns.php'</script>";
	}
	else
	{
		echo "<p>Something wrong in Return Update" . mysql_error() . "</p>";
	}
}
?>
<html>
<head>
<title>Return Update</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="stylesheet/styles.css" />

<style type="text/css">
body 
{
	background: #333333;
}

input[type=submit]
{
	background-color:#99FF00;
	color:black;
	font-weight: bold;
	border-radius: 5px;
	width:138px;
	height:30px;
	border-color: grey;
	margin-left: 25px;
	margin-top: 10px;

}

input[name=btnBooks]
{
	background-color:#FFCC00;
    width:125px;
    height:40px;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
    border: 1px solid black;
}

input[name=btnOrders]
{
	background-color:#CC0033;
    width:125px;
    height:40px;
    border: 1px solid black;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
}

input[name=btnDeliveries]
{
	background-color:#FFFF33;
    width:125px;
    height:40px;
    border:1px solid black;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
}

input[name=btnStock]
{
	background-color:#3366FF;
    width:125px;
    height:40px;
    border:1px solid black;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
}

input[name=btnCustomers]
{
	background-color:#FF00FF;
    width:125px;
    height:40px;
    border:1px solid black;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
}

input[name=btnSales]
{
	background-color:#33FF66;
    width:125px;
    height:40px;
    border:1px solid black;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
}

input[name=btnReturns]
{
	background-color:#FF3333;
    width:125px;
    height:40px;
    border:1px solid black;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
}


#container
{
    width: 220px;
    height: 440px;
    margin-top: -10px;
    margin-left: -40px;
    background:#CCCCCC;
    border-radius: 3px;
    border: 1px solid black;
    border-radius: 2px;
    font-size:14px;
    font-family: Arial;
}

#templatemo_container
{
	background: #333333;
	height: 100px;
	width: 1353px;
	border:1px solid #FFFFFF;
}

h2
{
   font-family: Arial;
   font-size:16;
   margin-left: 20px;
}

input[name=btnLogout]
{
	background:#FFFF66;
	margin-left: 1170px;
	width: 140px;
	height: 40px;
	border-radius: 5px;
	border:1px solid black;
	font-weight: bold;
	margin-top:-30px;
}

table
{
	margin-left: 200px;
	margin-top: -420px;
}

input[type=text]
{
	margin-top:10px;
	width: 177px;
	height: 22px;
}

th
{
	color:black;
	background:#FFFF66;
	border:1px;
	font-size:13;
	font-family: Arial;
	height:27px;
}

#search-button
{
	background:#FF6666;
	border-radius: 5px;
	width: 68px;
	height: 18px;
	font-size: 13;
	font-family: Arial;
	border-color:none;
}

#search-text
{
	width: 173px;
	height: 16px;
}

input[type=number]
{
	margin-top:10px;
	width:177px;
	height:22px;

}
</style>
</head>

<body>
<form action="ReturnUpdate.php" method="post">

<div id="templatemo_container" style="margin-left:-10px">
<br/>
<br/><h2>ADMIN SITE</h2>
<input type="button" name="btnLogout" value="Logout">
</div>

<table>
<tr>
	<td>ISBN</td>
	<td>
	<input type="text" name="txtISBN" value="<?php echo $ISBN ?>" required/>
	</td>
</tr>
<tr>
	<td>Quantity</td>
	<td>
	<input type="number" name="txtQuantity" value="<?php echo $Quantity?>" required/>
	</td>
</tr>

<tr>
	<td>Customer ID</td>
	<td>
	<input type="text" name="txtCustomerID" value="<?php echo $CustomerID?>" required/>
	</td>
</tr>

<tr>
	<td>Customer Name</td>
	<td>
	<input type="text" name="txtCustomerName" value="<?php echo $CustomerName?>" required/>
	</td>
</tr>

<tr>
	<td>Reason</td>
	<td>
	<input type="text" name="txtReason" value="<?php echo $Reason?>" required/>
	</td>
</tr>

<tr>
	<td>
	</td>
	<td>
	<input type="submit" name="btnUpdate" value="Update"/>
	</td>
</tr>
<div id="container" style="margin-top: 0px">
    <ul>
      	<li><input type="button" name="btnBooks" value="Books"></li>
       	<li><input type="button" name="btnOrders" value="Orders"></li>
       	<li><input type="button" name="btnDeliveries" value="Deliveries"></li>
       	<li><input type="button" name="btnStock" value="Stock"></li>
       	<li><input type="button" name="btnCustomers" value="Customers"></li>
       	<li><input type="button" name="btnSales" value="Sales"></li>
       	<li><input type="button" name="btnReturns" value="Returns"></li>
    </ul>
</div>  

</table>
</fieldset>
</form>
</body>
</html>
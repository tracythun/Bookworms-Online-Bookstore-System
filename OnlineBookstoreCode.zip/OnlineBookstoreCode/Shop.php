<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Book Store Template, Free CSS Template, CSS Website Layout</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- Add font awesome icons -->

</head>
</html>
<style>
#search-box
{
position: relative;
width: 98%;
margin: 0;
}

#search-form 
{
height: 28px;
border: 1px solid #999;
-webkit-border-radius: 5px;
-moz-border-radius: 5px;
border-radius: 5px;
background-color:#000000;
overflow: hidden;
}

#search-text 
{
font-size: 16px;
color:#ddd;
border-width: 0;
background: transparent;
}

#search-box input[type="text"]
{
width: 90%;
padding: 11px 0 12px 1em;
color:#fff;
outline: none;
}

#search-button {
position: absolute;
top: 0;
right: 0;
height: 29.5px;
width: 80px;
font-size: 14px;
color: #fff;
text-align: center;
line-height: 20px;
border-width: 0;
background-color:#ad4c01;
-webkit-border-radius: 0px 5px 5px 0px;
-moz-border-radius: 0px 5px 5px 0px;
border-radius: 0px 5px 5px 0px;
cursor: pointer;
}
</style>


<div id="templatemo_container">
	<div id="templatemo_menu">
    	<ul>
    	   <li><a href="Homepage.php" class="current">Home</a></li>
           <li><a href="Shop.php">Shop</a></li>  
           <li><a href="MyAccount.php">My Account</a></li>
           <li><a href="AboutUs.php">About Us</a></li>
           <li><a href="Contact.php">Contact</a></li>
           <li><a href="Help.php">Help</a></li>
        </ul>
        </div>
        
        <div id='search-box'>
        <form action='/search' id='search-form' method='get' target='_top'>
        <input id='search-text' placeholder='Search Here...' type='text'/>
        <button id='search-button' type='submit'><span>Search</span></button>
        </form>
        </div>
    

    <div id="templatemo_header">
     	<div id="templatemo_special_offers">
       	<p>
     	    <span>25%</span> discounts for
        purchase over $80
       	</p>
		<a href="subpage.html" style="margin-left: 50px;">Read more...</a>
        </div>
        
        
        <div id="templatemo_new_books">
        	<ul>
                <li>BECOMING</li>
                <li>NORMAL PEOPLE</li>
                <li>THE SADNESS OF BEAUTIFUL THINGS</li>
            </ul>
            <a href="subpage.html" style="margin-left: 50px;">Read more...</a>
        </div>
    </div> 

    <div id="templatemo_content">
        <div id="templatemo_content_left">
        	<div class="templatemo_content_left_section">
            	<h1>Categories</h1>
                <ul>
                   	<li><a href="#">> Autobiography</a></li>
                   	<li><a href="#">> Business</a></li>
                	<li><a href="#">> Children's Book</a></li>
                	<li><a href="#">> Computing</a></li>
                	<li><a href="#">> Cook book</a></li>
                	<li><a href="#">> Health</a></li>
                    <li><a href="#">> History</a></li>
                    <li><a href="#">> Novels</a></li>
                </ul>
            </div>
			<div class="templatemo_content_left_section">
            	<h1>Bestsellers</h1>
                <ul>
                	<li><a href="#">> Becoming</a></li>                     	
                	<li><a href="#">> Be Like the Fox: Machiavelli's Lifelong Quest for Freedom</a></li> 	
                	<li><a href="#">> Cracking the Coding Interview</a></li>
                	<li><a href="#">> Dirtcandy</a></li>
                	<li><a href="#">> How to Win Friends & Influence People</a></li>                	
                	<li><a href="#">> In Defense of Food: An Eater's Manifesto</a></li>
                	<li><a href="#">> The Wicked King</a></li>
                	<li><a href="#">> Ulysses</a></li>
                </ul>              
            </div>
            <p>Share</p>
            <a href="www.facebook.com" class="fa fa-facebook"></a>
			<a href="www.twitter.com" class="fa fa-twitter"></a>

            
        </div> <!-- end of content left -->
            <div id="templatemo_content_right">
        	<div class="templatemo_product_box">
            <img src="images/the_great_gatsby.jpg" alt="image" />
                <div class="product_info">
                	<p>The Great Gatsby</p>
                  <h3>$55.00</h3>
                    <div class="buy_now_button"><a href="subpage.html">Add To Cart</a></div>
                    <div class="detail_button"><a href="subpage.html">Detail</a></div>
                </div>
                <div class="cleaner">&nbsp;</div>
            </div>
            
            <div class="cleaner_with_width">&nbsp;</div>
            
            <div class="templatemo_product_box">
            <img src="images/messenger.jpg" alt="image" />
                <div class="product_info">
                	<p>Messenger of Fear</p>
                    <h3>$40.00</h3>
                    <div class="buy_now_button"><a href="subpage.html">Add To Cart</a></div>
                    <div class="detail_button"><a href="subpage.html">Detail</a></div>
                </div>
                <div class="cleaner">&nbsp;</div>
            </div>
            
            <div class="cleaner_with_height">&nbsp;</div>
            
            <div class="templatemo_product_box">
            <img src="images/3pigs.jpg" alt="image" />
                <div class="product_info">
                	<p>The Three Little Pigs</p>
                    <h3>$18.00</h3>
                    <div class="buy_now_button"><a href="subpage.html">Add To Cart</a></div>
                    <div class="detail_button"><a href="subpage.html">Detail</a></div>
                </div>
                <div class="cleaner">&nbsp;</div>
            </div>
            
            <div class="cleaner_with_width">&nbsp;</div>
            
            <div class="templatemo_product_box">
              	<img src="images/sushi.jpg" alt="image" />
                <div class="product_info">
                	<p>Sushi: Taste and Techniques </p>
                    <h3>$40.00</h3>
                    <div class="buy_now_button"><a href="subpage.html">Add To Cart</a></div>
                    <div class="detail_button"><a href="subpage.html">Detail</a></div>
                </div>
                <div class="cleaner">&nbsp;</div>
            </div>
            
            <div class="cleaner_with_height">&nbsp;</div>
            
        </div> 
    
    	<div class="cleaner_with_height">&nbsp;</div>
    </div> 
    
    <div id="templatemo_footer">

    <p>
	    <a href="Homepage.php">Home</a>| <a href="Shop.php">Shop</a>| <a href="MyAccount.php">My Account</a>| <a href="AboutUs.php">About Us</a>| <a href="Contact.php">Contact</a>| <a href="Help.php">Help <br/>
	</p>
    <p>
        Copyright © 2019 <a href="http://www.bookworms.com/"> <strong>Bookworm</strong></a> 
	</p>       
      <img src="images/paypal.png" style="margin-left: 700px";>
      <img src="images/visa.png">
      <img src="images/mastercard.jpg"></li>
    </div> 
</div> 
</body>
</html>

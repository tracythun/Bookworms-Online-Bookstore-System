<?php 
include ('connect.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Book Store Template, Free CSS Template, CSS Website Layout</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<head>
	<title>Help</title>
</head>
<style>

#search-box
{
position: relative;
width: 98%;
margin: 0;
}

#search-form 
{
height: 28px;
border: 1px solid #999;
-webkit-border-radius: 5px;
-moz-border-radius: 5px;
border-radius: 5px;
background-color:#000000;
overflow: hidden;
}

#search-text 
{
font-size: 16px;
color:#ddd;
border-width: 0;
background: transparent;
}

#search-box input[type="text"]
{
width: 90%;
padding: 11px 0 12px 1em;
color:#fff;
outline: none;
}

#search-button {
position: absolute;
top: 0;
right: 0;
height: 29.5px;
width: 80px;
font-size: 14px;
color: #fff;
text-align: center;
line-height: 20px;
border-width: 0;
background-color:#ad4c01;
-webkit-border-radius: 0px 5px 5px 0px;
-moz-border-radius: 0px 5px 5px 0px;
border-radius: 0px 5px 5px 0px;
cursor: pointer;
}
</style>
<body>

<div id="templatemo_container">
	<div id="templatemo_menu">
    	<ul>
    	   <li><a href="Homepage.php" class="current">Home</a></li>
           <li><a href="Shoppingcart.php">My Cart</a></li>
           <li><a href="AboutUs.php">About Us</a></li>
           <li><a href="Contact.php">Contact</a></li>
           <li><a href="Help.php">Help</a></li>
           <li><a href="Logout.php" style="margin-left: 340px">Log Out</a></li>
        </ul>
    </div>
        
    <div id='search-box'>
        <form action='/search' id='search-form' method='get' target='_top'>
        <input id='search-text' placeholder='Search Here...' type='text'/>
        <button id='search-button' type='submit'><span>Search</span></button>
        </form>
    </div>
    
    <div id="templatemo_header">
     	<div id="templatemo_special_offers">
        	<p>
        	    <span>25%</span> discounts for
                purchase over $80
       	    </p>
		    <a href="#" style="margin-left: 50px;">Read more...</a>
        </div>
                
        <div id="templatemo_new_books">
        	<ul>
                <li>BECOMING</li>
                <li>NORMAL PEOPLE</li>
                <li>THE SADNESS OF BEAUTIFUL THINGS</li>
            </ul>
            <a href="#" style="margin-left: 50px;">Read more...</a>
        </div>
    </div> 

    <div id="templatemo_content">
        <div id="templatemo_content_left">
        	<div class="templatemo_content_left_section">
            	<h1>Categories</h1>
                <ul>
                   <ul>
              <li>
              <?php  
              $query="SELECT * FROM Book";
              $result=mysql_query($query);
              $count=mysql_num_rows($result);
              ?>
              <?php  
              for ($i=0;$i<$count;$i++) 
              { 
                $array=mysql_fetch_array($result);

              $BookType=$array['BookType'];
              echo "<tr>";
              echo "<td><li><a href='categories.php?BookType=$BookType'>> $BookType</li></td>";
              echo "</tr>";
              }
              ?>
                </ul>
            </div>
			
            <div class="templatemo_content_left_section">
            	<h1>Bestsellers</h1>
                <ul>
                	<li><a href="#">> Becoming</a></li>                     	
                	<li><a href="#">> Be Like the Fox: Machiavelli's Lifelong Quest for Freedom</a></li> 	
                	<li><a href="#">> Cracking the Coding Interview</a></li>
                	<li><a href="#">> Dirtcandy</a></li>
                	<li><a href="#">> How to Win Friends & Influence People</a></li>                	
                	<li><a href="#">> In Defense of Food: An Eater's Manifesto</a></li>
                	<li><a href="#">> The Wicked King</a></li>
                	<li><a href="#">> Ulysses</a></li>
                </ul>              
            </div>
            
            <p>Share</p>
            <a href="https://www.facebook.com/bookwormbooksmyanmaronline/" class="fa fa-facebook"></a>
			<a href="#" class="fa fa-twitter"></a>
          
        </div> <!-- end of content left -->
    </div>

    <label><h3 style="color:#ff5544">Help</h3></label>
    <h3 style="color: #eefffe"><u>Common Questions</u></h3>
    1.How can I contact you?
 	<p>You can contact us by clicking 'Contact' on the menu bar.</p>
	<br/>
	2. How much is for delivery?
	<p>Delivery charges depends on your address. Thus, you will have to pay for both order and delivery fee.</p>
	<br/>
	3.Can I pay with cards online?
	<p>In order to make sure no problems occur, we will only collect payment by cash-on-delivery(COD). This means you'll only have to pay when the order reach your hands.</p>
	<br/>
	4.Do you also deliver the books to other places apart from Yangon?
	<p>Yes, we do deliver the books throughout Myanmar. We used to send the books with the high-way expresses.</p>
	<br/>
	5.Do you deliver the books outside Myanmar?
	<p>No, we intended to sell within Myanmar only.</p>
	<br/>
	6.How much time do I have to wait for my order?
	<p>The waiting time will depend on the ordered lists. If there are many orders, time may vary.</p>
	<br/>
	7. How can I know when the delivery will arive?
	<p>We will contact you via phone to confirm about the delivery.</p>
	<br/>
	8. How can I cancel my order?
	<p>If you wish to cancel your order, please contact our bookstores' phone numbers or write a message in contact page within a week. You can also message us on Messenger from Facebook. However, if you send the message after a week, you will not be able to cancel your order but accept it.


<div id="templatemo_footer">
    <p>
	    <a href="Homepage.php">Home</a>| <a href="Shop.php">Shop</a>|<a href="AboutUs.php">About Us</a>|<a href="Contact.php">Contact</a>| <a href="Help.php">Help</a><br/>
	</p>
    <p>
        Copyright © 2019<p><strong>Bookworm</strong></p> 
	</p> 
    </div> 
</div>
</body>
</html>

</body>
</html>
<?php  
include('connect.php');

$Email=$_REQUEST['Email'];

$query="DELETE FROM Messages WHERE Email='$Email'";
$result=mysql_query($query);

if($result) //True 
{
	echo "<script>window.alert('Message Successfully Deleted.')</script>";
	echo "<script>window.location='Messages.php'</script>";
}
else
{
	echo "<p>Something wrong in Message Delete" . mysql_error() . "</p>";
}
?>
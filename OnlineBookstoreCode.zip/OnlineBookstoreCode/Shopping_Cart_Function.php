<?php  
function AddShoppingCart($ISBN,$BuyQuantity)
{
	$query="SELECT * FROM Book WHERE ISBN='$ISBN'";
	$result=mysql_query($query);
	$count=mysql_num_rows($result);

	if($count < 1) 
	{
		echo "<p>No Book Infomation found.</p>";
		exit();
	}

	$rows=mysql_fetch_array($result);

	$ISBN=$rows['ISBN'];
	$BookName=$rows['BookName'];
	$AuthorName=$rows['AuthorName'];
	$BookType=$rows['BookType'];
	$Image=$rows['Image'];
	$Price=$rows['Price'];
	$Quantity=$rows['Quantity'];

	if($BuyQuantity < 1)
	{
		echo "<script>window.alert('Buying Quantity cannot be Zero (0).')</script>";
		echo "<script>window.location='ShoppingCart.php'</script>";
	}
	
	if($BuyQuantity > $Quantity)
	{
		echo "<script>window.alert('Please enter correct Quantity')</script>";
		echo "<script>window.location='ShoppingCart.php'</script>";
	}

	if(isset($_SESSION['ShoppingCart_Function'])) 
	{
		$index=IndexOf($ISBN);

		if($index == -1) 
		{
			$size=count($_SESSION['ShoppingCart_Function']);

			$_SESSION['ShoppingCart_Function'][$size]['Image']=$Image;	
			$_SESSION['ShoppingCart_Function'][$size]['ISBN']=$ISBN;
			$_SESSION['ShoppingCart_Function'][$size]['BookName']=$BookName;
			$_SESSION['ShoppingCart_Function'][$size]['AuthorName']=$AuthorName;
			$_SESSION['ShoppingCart_Function'][$size]['BookType']=$BookType;
			$_SESSION['ShoppingCart_Function'][$size]['Price']=$Price;
			$_SESSION['ShoppingCart_Function'][$size]['BuyQuantity']=$BuyQuantity;
			}
		else
		{
			$_SESSION['ShoppingCart_Function'][$index]['BuyQuantity']+=$BuyQuantity;
		}
	}
	else
	{
		$_SESSION['ShoppingCart_Function']=array();

		$_SESSION['ShoppingCart_Function'][0]['Image']=$Image;
		$_SESSION['ShoppingCart_Function'][0]['ISBN']=$ISBN;
		$_SESSION['ShoppingCart_Function'][0]['BookName']=$BookName;
		$_SESSION['ShoppingCart_Function'][0]['AuthorName']=$AuthorName;
		$_SESSION['ShoppingCart_Function'][0]['BookType']=$BookType;
		$_SESSION['ShoppingCart_Function'][0]['Price']=$Price;
		$_SESSION['ShoppingCart_Function'][0]['BuyQuantity']=$BuyQuantity;
	}
	//echo "<script>window.location='Shopping_Cart.php'</script>";
}

function IndexOf($ISBN)
{
	if(!isset($_SESSION['ShoppingCart_Function'])) 
	{
		return -1;
	}

	$count=count($_SESSION['ShoppingCart_Function']);

	if ($count < 1) 
	{
		return -1;
	}

	for ($i=0;$i<$count;$i++) 
	{ 
		if($_SESSION['ShoppingCart_Function'][$i]['ISBN'] == $ISBN) 
		{
			return $i;
		}
	}
	return -1;
}

function CalculateTotalAmount()
{
	$TotalAmount=0;

	$count=count($_SESSION['ShoppingCart_Function']);

	for($i=0;$i<$count;$i++) 
	{ 
		$Price=$_SESSION['ShoppingCart_Function'][$i]['Price'];
		$Quantity=$_SESSION['ShoppingCart_Function'][$i]['BuyQuantity'];

		$TotalAmount=$TotalAmount+($Price * $Quantity);
	}

	return $TotalAmount;
}

function CalculateTotalQuantity()
{
	$TotalQuantity=0;

	$count=count($_SESSION['ShoppingCart_Function']);

	for($i=0;$i<$count;$i++) 
	{ 
		$Quantity=$_SESSION['ShoppingCart_Function'][$i]['BuyQuantity'];

		$TotalQuantity=$TotalQuantity+($Quantity);
	}

	return $TotalQuantity;
}

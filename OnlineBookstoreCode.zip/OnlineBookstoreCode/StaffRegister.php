<?php
session_start();
include ('connect.php'); 

if(isset($_POST['btnRegister']))
{
	$txtFirstName=$_POST['txtFirstName'];
	$txtLastName=$_POST['txtLastName'];
    $txtDOB=$_POST['txtDOB'];
    $txtPosition=$_POST['txtPosition'];
    $txtPhone=$_POST['txtPhone'];
    $txtEmail=$_POST['txtEmail'];
    $txtPassword=$_POST['txtPassword'];

    $checkStaff="SELECT * FROM Staff
    Where FirstName='$txtFirstName'";

    $result=mysql_query($checkStaff);
    $count=mysql_num_rows($result);
    
    if ($count!=0)
    {
        echo "<script>window.alert('FirstName $txtFirstName already exist in Database.')</script>";
        echo "<script>window.location='StaffRegister.php'</script>";
        exit();
    }

    $query="INSERT INTO Staff(`FirstName`,`LastName`,`DOB`,`Position`,`Phone`,`Email`,`Password`)
    VALUES ('$txtFirstName','$txtLastName','$txtDOB','$txtPosition','$txtPhone','$txtEmail','$txtPassword')";

    $result=mysql_query($query);

    if($result)
    {
        echo "<script>window.alert('Register sucessful')</script>";
        echo "<script>window.location='Login.php'</script>";  
    }
    else
    {
        echo "<p>Something wrong in Staff Register" . mysql_error() . "</p>";
    }
}
?>

<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css"/>


<style>
html, body 
{   
    width: 100%;   
    height: 100%;   
    font-family: "Helvetica Neue", Helvetica, sans-serif;   
    color: #444;   
    -webkit-font-smoothing: antialiased; background:url(BookImages/bookworm.jpg)no-repeat center;
}

#container 
{
    position: fixed;
    width: 340px;
    height: 30px;
    top: 50%;
    left: 50%;
    margin-top: -140px;
    margin-left: -170px;
}

form
{
   margin: 0 auto;
   margin-top: 20px;
}

label 
{
    color: black;
    display: inline-block;
    margin-left: 20px;
    padding-top: 12px;
    font-size: 14px;
}

legend
{
    color:black;
    display: inline-block;
    margin-left: 10px;
    padding-top: 10px;
    font-size: 15px;
}

input 
{
    font-family: "Verdana";
    font-size: 15px;
    outline: none;
}

#lower
{
    background: #9999FF;
    width: 100%;
    height: 80px margin-top: 20px;
}

input[type=submit]
{
    margin-left: 10px;
    margin-bottom: 20px;
    width: 80px;
    height: 30px;

    background: #fff;
    border-radius: 3px;
    border: 1px solid #ccc;
    box-shadow: 0 1px 2px rgba(0, 0, 0, .1);
}

input[type=text]
{
   width:240px;
   height: 25px;
   margin-left: -10px;
   border:1px solid black;
}

input[type=password]
{
   width:240px;
   height:25px;
   margin-left: -10px;
   border:1px solid black;
}

input[type=date]
{
    width:240px;
    height:25px;
    margin-left: -10px;
    border:1px solid black;
}

#container
{
    position: fixed;
    width: 270px;
    height: 365px;
    top: 50%;
    left: 52%;
    margin-top: -140px;
    margin-left: -170px;
    background:#9999FF;
    border-radius: 3px;
    border: 1px solid #ccc;
    box-shadow: 0 1px 2px rgba(0, 0, 0, .1);

    border: 1px solid #bb99ff;
    border-radius: 2px;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 1px black;
}


input[type=submit] 
{
    float: left 20px;
    margin-right: 20px;
    margin-top: -30px;
    width: 110px;
    height: 35px;
    font-size: 11px;
    font-weight: bold;
    color:black;
    background-color: #acd6ef; /*IE fallback*/
    background-image: -webkit-gradient(linear, left top, left bottom, from(#ffff00), to(#ffff00));
    background-image: -moz-linear-gradient(top left 90deg, #acd6ef 0%, #6ec2e8 100%);
    background-image: linear-gradient(top left 90deg, #acd6ef 0%, #6ec2e8 100%);
    border-radius: 5px ;
    border: 1px solid grey;
    box-shadow: 0 1px 2px rgba(0, 0, 0, .3), inset 0 1px 0 rgba(255, 255, 255, .5);
    cursor: pointer;
}

input[type=reset]
{
    width: 107px;
    height: 35px; 
    font-size:11px;
    font-weight: bold;
    border-radius: 5px;
    border: 1px solid grey;
    background-image: -webkit-gradient(linear, left top, left bottom, from(#a6ff4d), to(#a6ff4d));   


}
</style>
</head>
<?php
$time=time();
$today=date('j',$time);
$days=array($today=>array(null,null,'<div id="today">'.$today.'</div>'));
$pn=array('&laquo;'=>date('n',$time)-1,'&raquo;'=>date('n',$time)+1);

function generate_calendar($year,$month,$days=array(),$day_name_length=3,$month_href=NULL,$first_day=0,$pn=array())
{
    $first_of_month=gmmktime(0,0,0,$month,1,$year);
    $day_names=array(); 
    for($n=0,$t=(3+$first_day)*86400;$n<7;$n++,$t+=86400)
    $day_names[$n]=ucfirst(gmstrftime('%A',$t)); 

    list($month,$year,$month_name,$weekday)=explode(',',gmstrftime('%m,%Y,%B,%w',$first_of_month));
    $weekday=($weekday+7-$first_day)%7;
    $title=htmlentities(ucfirst($month_name)).$year;  
    @list($p, $pl)=each($pn);@list($n,$nl)=each($pn); 
    if($p)$p='<span class="calendar-prev">'.($pl?'<a href="'.htmlspecialchars($pl).'">'.$p.'</a>':$p).'</span>&nbsp;';
    if($n)$n='&nbsp;<span class="calendar-next">'.($nl?'<a href="'.htmlspecialchars($nl).'">'. $n.'</a>':$n).'</span>';
    $calendar="<div class=\"mini_calendar\">\n<table>"."\n". 
    '<caption class="calendar-month">'.$p.($month_href?'<a href="'.htmlspecialchars($month_href).'">'.$title.'</a>':$title).$n."</caption>\n<tr>";

    if($day_name_length)
    { 
        foreach($day_names as $d)
        $calendar.='<th abbr="'.htmlentities($d).'">'.htmlentities($day_name_length<4?substr($d,0,$day_name_length):$d).'</th>';
        $calendar.="</tr>\n<tr>";   
    }
    if($weekday>0) 
    {
        for($i=0;$i<$weekday;$i++) 
        {
            $calendar.='<td>&nbsp;</td>'; 
        }
    }
    for($day=1,$days_in_month=gmdate('t',$first_of_month);$day<=$days_in_month;$day++,$weekday++)
    {
        if($weekday==7)
        {
            $weekday=0;
            $calendar.="</tr>\n<tr>";
        }
        if(isset($days[$day])and is_array($days[$day]))
        {
            @list($link,$classes,$content)=$days[$day];
            if(is_null($content))$content=$day;
            $calendar.='<td'.($classes?'class="'.htmlspecialchars($classes).'">':'>') . 
                ($link ?'<a href="'.htmlspecialchars($link).'">'.$content.'</a>':$content).'</td>';
        }
        else $calendar.="<td>$day</td>";
    }
    if($weekday!=7)$calendar.='<td id="emptydays"colspan="'.(7-$weekday).'">&nbsp;</td>';
    return $calendar."</tr>\n</table>\n</div>\n";
}
?>
<html>
<form action="StaffRegister.php" method="post">
<div id="container">
<legend>Register an Account</legend>
    <label>
    <input type="text" placeholder="First Name" name="txtFirstName" required/>
    </label>
    <br/>

    <label>
    <input type="text" placeholder="Last Name" name="txtLastName" required/>
    </label>
    <br/>


    <label>
    Date Of Birth<input type="date" name="txtDOB">
    </label>
    <br/>

    <label>
    <input type="text" name="txtPosition" placeholder="Position" required/>
    </label>
    <br/>


    <label>
    <input type="text" name="txtPhone" placeholder="Phone" required/>
    </label>
    <br/>

    <label>
    <input type="text" name="txtEmail" placeholder="Email" required/>
    </label>
    <br/>

    <label>
    <input type="Password" name="txtPassword" placeholder="Password" required/>
    </label>
    <br/>

    <div id="lower">
    <br/>
    <input type="submit" name="btnRegister" value="Register"/>
    <input type="reset" value="Cancel"/>
    </div>
</div>
</form>
</body>
</html>


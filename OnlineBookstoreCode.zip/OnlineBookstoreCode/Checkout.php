<?php  
session_start(); 
include('connect.php'); 
include('Shopping_Cart_Function.php');

function ClearAll()
{
	unset($_SESSION['ShoppingCart_Function']);
	echo "<script>window.location='Checkout.php'</script>";
}

function Remove($ISBN)
{
	$index=IndexOf($ISBN);
	unset($_SESSION['ShoppingCart_Function'][$index]);
	echo "<script>window.location='Checkout.php'</script>";
}

if(!isset($_SESSION["CustomerID"]))
{
		echo "<script>window.alert('Please Login')</script>";
		echo "<script>window.location='Login.php'</script>";
}

else
{
	$CustomerID=$_SESSION["CustomerID"];

	if(isset($_GET["Order"]))
	{
		$Order=$_GET['Order'];

		 $sel="SELECT * from Order
		      Where OrderID='$Order'";

		$ret=mysql_query($sel);
		$arr=mysql_fetch_array($ret);

		echo$fee=$arr['Fee'];
	}
	else
	{
		$Order='';
	}	
}


if(isset($_GET['action'])) 
{
  $action=$_GET['action'];

  if($action==="Remove") 
  {
    $ISBN=$_GET['ISBN'];
    Remove($ISBN);
  }
  elseif($action==="Clear") 
  {
    ClearAll();
  }
}

if(isset($_POST['btnCheckout'])) 
{
	$txtOrderID=$_POST['txtOrderID'];
	$txtOrderDate=$_POST['txtOrderDate'];
	$txtCustomerID=$_POST['txtCustomerID'];
	$txtPhoneNumber=$_POST['txtPhoneNumber'];
	$txtAddress=$_POST['txtAddress'];

	$TotalAmount=CalculateTotalAmount();
	$TotalQuantity=CalculateTotalQuantity();
	
	$Status="Pending";

	$checkOrder="SELECT * FROM Order1
			 	Where CustomerID='$txtCustomerID'";
	$result=mysql_query($checkOrder);

	$count=mysql_num_rows($result);
	
	if ($count!=0)
	{
		echo "<script>window.alert('You cannot order yet.')</script>";
		echo "<script>window.location='Checkout.php'</script>";
		exit();
	}

	$query="INSERT INTO `Order1`
			(`OrderID`, `CustomerID`, `OrderDate`, `TotalAmount`, `TotalQuantity`,`PhoneNumber`,`Address`,`Status`) 
			VALUES
			('$OrderID','$CustomerID','$txtOrderDate','$TotalAmount','$TotalQuantity','$txtPhoneNumber','$txtAddress','$Status')";
	$result=mysql_query($query);

	//OrderDetail Save======================================================

	$count=count($_SESSION['ShoppingCart_Function']);
	for($i=0; $i < $count; $i++) 
	{ 
		$ISBN=$_SESSION['ShoppingCart_Function'][$i]['ISBN'];
		$Price=$_SESSION['ShoppingCart_Function'][$i]['Price'];
		$Quantity=$_SESSION['ShoppingCart_Function'][$i]['BuyQuantity'];

		$query_Detail="INSERT INTO `OrderDetail`
					   (`CustomerID`,`ISBN`, `Price`, `Quantity`) 
						VALUES 
					   ('$CustomerID','$ISBN','$Price','$Quantity')";
		$result=mysql_query($query_Detail);
	}
	//=======================================================================

	if($result) 
	{
			echo "<script>window.alert('Checkout Successful!')</script>";
			echo "<script>window.location='Homepage.php'</script>";
	}
	else
	{
			echo "<p>Something wrong in Checkout" . mysql_error() . "</p>";
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Book Store Template, Free CSS Template, CSS Website Layout</title>
<meta name="keywords" content="" />

<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
</html>

<style>

#search-box
{
position: relative;
width: 98%;
margin: 0;
}

#search-form 
{
height: 28px;
border: 1px solid #999;
-webkit-border-radius: 5px;
-moz-border-radius: 5px;
border-radius: 5px;
background-color:#000000;
overflow: hidden;
}

#search-text 
{
font-size: 16px;
color:#ddd;
border-width: 0;
background: transparent;
}

#search-box input[type="text"]
{
width: 90%;
padding: 11px 0 12px 1em;
color:#fff;
outline: none;
}

#search-button {
position: absolute;
top: 0;
right: 0;
height: 29.5px;
width: 80px;
font-size: 14px;
color: #fff;
text-align: center;
line-height: 20px;
border-width: 0;
background-color:#ad4c01;
-webkit-border-radius: 0px 5px 5px 0px;
-moz-border-radius: 0px 5px 5px 0px;
border-radius: 0px 5px 5px 0px;
cursor: pointer;
}

input[type=text]
{
	margin-top: 10px;
}

input[name=btnCheckout]
{
    background: #FFCC33;
    font-weight: bold;
    width:103px;
    height:40px;
    border-color:grey;
    border-radius:6px;
}

input[type=textarea]
{
	margin-top: 10px;
}

</style>


<div id="templatemo_container">
  <div id="templatemo_menu">
      <ul>
         <li><a href="Homepage.php" class="current">Home</a></li>
           <li><a href="ShoppingCart.php">My Cart</a></li>  
           <li><a href="MyAccount.php">My Account</a></li>
           <li><a href="AboutUs.php">About Us</a></li>
           <li><a href="Contact.php">Contact</a></li>
           <li><a href="Help.php">Help</a></li>
           <a href="Logout.php" style="margin-left: 340px">Sign Out</a>
        </ul>
    </div>
        
    <div id='search-box'>
        <form action='/search' id='search-form' method='get' target='_top'>
        <input id='search-text' placeholder='Search Here...' type='text'/>
        <button id='search-button' type='submit'><span>Search</span></button>
        </form>
    </div>
    

    <div id="templatemo_header">
      <div id="templatemo_special_offers">
          <p>
              <span>25%</span> discounts for
                purchase over $80
            </p>
        <a href="subpage.html" style="margin-left: 50px;">Read more...</a>
        </div>
                
        <div id="templatemo_new_books">
          <ul>
                <li>BECOMING</li>
                <li>NORMAL PEOPLE</li>
                <li>THE SADNESS OF BEAUTIFUL THINGS</li>
            </ul>
            <a href="subpage.html" style="margin-left: 50px;">Read more...</a>
        </div>
    </div> 

<html>
<head>
	<title>Secure Checkout</title>
</head>
<body>
<form action="Checkout.php" method="post">
<fieldset>
<legend>Enter Checkout Info:</legend>

<table>
<tr>
	<td>Order Date</td>
	<td>
	<input type="text" name="txtOrderDate" value="<?php echo date('Y-m-d') ?>" readonly/>
	</td>
</tr>
<tr>
	<td>Customer ID</td>
	<td>
	<input type="text" name="txtCustomerID" value="<?php echo $CustomerID?>" required/>
	</td>
</tr>
<tr>
	<td>Total Amount</td>
	<td>
	<input type="text" value="<?php echo CalculateTotalAmount() ?>" readonly/> MMK
	</td>
</tr>
<tr>
	<td>Total Quantity</td>
	<td>
	<input type="text" value="<?php echo CalculateTotalQuantity() ?>" readonly/>
	</td>
</tr>

<tr>
	<td>Phone Number</td>
	<td><input type="text" name="txtPhoneNumber" required/></td>
</tr>

<tr>
	<td>Address:</td>
	<td><input type="textarea" name="txtAddress" required/></td>
</tr>

<tr>
	<td><input type="submit" name="btnCheckout" value="Checkout"/></td>
</tr>
</table>
</fieldset>

<fieldset>
<legend>Shopping Cart Details:</legend>
<table cellpadding="8px">
<tr>
	<th>Image</th>
	<th>ISBN</th>
	<th>Book Name</th>
	<th>Author Name</th>
	<th>Book Type</th>
	<th>Price</th>
	<th>Quantity</th>
	<th>Sub-Total</th>
	<th>Actions</th>
</tr>

<?php  
$count=count($_SESSION['ShoppingCart_Function']);

for($i=0;$i<$count;$i++) 
{ 
	$ISBN=$_SESSION['ShoppingCart_Function'][$i]['ISBN'];
	$Image=$_SESSION['ShoppingCart_Function'][$i]['Image'];

	echo "<tr>";
	echo "<td><img src='$Image' width='100' height='100'/></td>";
	echo "<td>" . $_SESSION['ShoppingCart_Function'][$i]['ISBN'] ."</td>";
	echo "<td>" . $_SESSION['ShoppingCart_Function'][$i]['BookName'] ."</td>";
	echo "<td>" . $_SESSION['ShoppingCart_Function'][$i]['AuthorName'] ."</td>";
	echo "<td>" . $_SESSION['ShoppingCart_Function'][$i]['BookType'] ."</td>";

	echo "<td>" . $_SESSION['ShoppingCart_Function'][$i]['Price'] ." MMK</td>";
	echo "<td>" . $_SESSION['ShoppingCart_Function'][$i]['BuyQuantity'] ." pcs</td>";

	echo "<td>" . $_SESSION['ShoppingCart_Function'][$i]['BuyQuantity'] * $_SESSION['ShoppingCart_Function'][$i]['Price'] ." MMK</td>";
    
    echo "<td><a href='Checkout.php?action=Remove&ISBN=$ISBN'>Remove</a></td>";
	echo "</tr>";
}
?>

<table>
    <tr>
      <td>Share</td>
    </tr>
    <tr>
      <td><a href="www.facebook.com" class="fa fa-facebook"></a></td>
      <td><a href="www.twitter.com" class="fa fa-twitter"></a></td>
    </tr>
</table>
</table>
</fieldset>	
</form>

</fieldset> 
    <div id="templatemo_footer">
    <p>
      <a href="Homepage.php">Home</a>| <a href="Shop.php">Shop</a>| <a href="MyAccount.php">My Account</a>| <a href="AboutUs.php">About Us</a>| <a href="Contact.php">Contact</a>| <a href="Help.php">Help</a><br/>
    </p>
    <p>
        Copyright © 2019<p><strong>Bookworm</strong></p>
    </p> 
    </div> 
</fieldset>
</body>
</html>
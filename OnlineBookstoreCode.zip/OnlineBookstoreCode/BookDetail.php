<?php
session_start();
include ('connect.php'); 
$ISBN=$_GET['ISBN'];

$query="SELECT * FROM Book WHERE ISBN='$ISBN'";
$result=mysql_query($query);
$arr=mysql_fetch_array($result);
$ISBN=$arr['ISBN'];
$BookName=$arr['BookName'];
$AuthorName=$arr['AuthorName'];
$BookType=$arr['BookType'];
$Description=$arr['Description'];
$Price=$arr['Price'];
$Quantity=$arr['Quantity'];
    
$Image=$arr['Image'];
list($width,$height)=getimagesize($Image);
$w=$width/3.5;
$h=$height/3.5;
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<title>Book Detail:</title>
</head>
</html>
<style>
#search-box
{
position: relative;
width: 98%;
margin: 0;
}

#search-form 
{
height: 28px;
border: 1px solid #999;
-webkit-border-radius: 5px;
-moz-border-radius: 5px;
border-radius: 5px;
background-color:#000000;
overflow: hidden;
}

#search-text 
{
font-size: 16px;
color:#ddd;
border-width: 0;
background: transparent;
}

#search-box input[type="text"]
{
width: 90%;
padding: 11px 0 12px 1em;
color:#fff;
outline: none;
}

#search-button {
position: absolute;
top: 0;
right: 0;
height: 29.5px;
width: 80px;
font-size: 14px;
color: #fff;
text-align: center;
line-height: 20px;
border-width: 0;
background-color:#ad4c01;
-webkit-border-radius: 0px 5px 5px 0px;
-moz-border-radius: 0px 5px 5px 0px;
border-radius: 0px 5px 5px 0px;
cursor: pointer;
}

input[name=btnAddtoCart]
{
    background:#FFCC33;
    color: white;
    font-weight: bold;
    width:100px;
    height:25px;
    margin-top:10px;
    margin-bottom:10px;
    font-family: Arial;
    font-size:13;
    border-radius: 6px;
    border-color: grey;
}
</style>

<div id="templatemo_container">
	<div id="templatemo_menu">
    	<ul>
    	   <li><a href="Homepage.php" class="current">Home</a></li>
           <li><a href="ShoppingCart.php">My Cart</a></li>  
           <li><a href="MyAccount.php">My Account</a></li>
           <li><a href="AboutUs.php">About Us</a></li>
           <li><a href="Contact.php">Contact</a></li>
           <li><a href="Help.php">Help</a></li>
        </ul>
        </div>
        
        <div id='search-box'>
        <form action='/search' id='search-form' method='get' target='_top'>
        <input id='search-text' placeholder='Search Here...' type='text'/>
        <button id='search-button' type='submit'><span>Search</span></button>
        </form>
        </div>
    

    <div id="templatemo_header">
     	<div id="templatemo_special_offers">
       	<p>
     	    <span>25%</span> discounts for
        purchase over $80
       	</p>
	     	<a href="subpage.html" style="margin-left: 50px;">Read more...</a>
      </div>
        
        
      <div id="templatemo_new_books">
       	<ul>
            <li>BECOMING</li>
            <li>NORMAL PEOPLE</li>
            <li>THE SADNESS OF BEAUTIFUL THINGS</li>
            </ul>
            <a href="subpage.html" style="margin-left: 50px;">Read more...</a>
      </div>
    </div>  
  
  <body>
    <form action="ShoppingCart.php" method="get">
    <input type="hidden" name="ISBN" value="<?php echo $ISBN ?>"/>

    <input type="hidden" name="action" value="Add"/>
    
  <legend><?php echo $arr['BookName'] ?> Detail :</legend>

    <table align="left" style="margin-left: 40px">
        <tr>
          <td>
            <img src="<?php echo $Image ?>" width="150" height="150"/>
          </td>
    
          <td>
            <table cellspacing="3px" style="margin-left:50px">
              <tr>
                 <td>ISBN:</td>
                 <td><?php echo $ISBN?></td>
              </tr>
              
              <tr>
                 <td>Book Name:</td>
                 <td><?php echo $BookName?></td>
              </tr>
              <tr>
                 <td>Author Name:</td>
                 <td><?php echo $AuthorName?></td>
              </tr>
              <tr>
                 <td>Book Type:</td>
                 <td><?php echo $BookType?></td>
              </tr>
              <tr>
                 <td>Description:</td>
                 <td><?php echo $Description?></td>
              </tr>
              <tr>
                 <td>Price:</td>
                 <td><?php echo $Price?>MMK</td>
              </tr>
              <tr>
                <td>Quantity:</td>
                <td><?php echo $Quantity?>  book left in the stock
                <?php  
                if($Quantity==0) 
                {
                  echo "<p>Out of Stock</p>";
                  exit();
                }
                ?>
                </td>
              </tr>
              <tr>
                <td></td>
                <td>
                  <input type="number" name="txtBuyQty" value="1" min="1"/>
                  <input type="submit" name="btnAddtoCart" value="Add to Cart"/>
                </td>
              </tr>
            </table>
          <tr>
          <td>Share</td>
          </tr>
          <tr>
          <td><a href="www.facebook.com" class="fa fa-facebook"></a>
            <a href="www.twitter.com" class="fa fa-twitter"></a>
          </td>
          </tr>
        </td>
      </tr> 
    </table> 
 </form>
</body>
<div id="templatemo_footer">  
  <p>
    <a href="Homepage.php">Home</a>| <a href="Shop.php">Shop</a>| <a href="MyAccount.php">My Account</a>| <a href="AboutUs.php">About Us</a><a href="Contact.php">Contact</a>| <a href="Help.php">Help <br/>
	</p>

  <p>
      Copyright © 2019 <a href="http://www.bookworms.com/"> <strong>Bookworm</strong></a> 
	</p> 
</div>
</html>

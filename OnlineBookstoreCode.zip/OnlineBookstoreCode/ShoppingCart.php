<?php 
session_start();
include('connect.php');
include('Shopping_Cart_Function.php');

function ClearAll()
{
  unset($_SESSION['ShoppingCart_Function']);
  echo "<script>window.location='ShoppingCart.php'</script>";
}

function Remove($ISBN)
{
  $index=IndexOf($ISBN);
  unset($_SESSION['ShoppingCart_Function'][$index]);
  echo "<script>window.location='ShoppingCart.php'</script>";
}

if(isset($_GET['action'])) 
{
  $action=$_GET['action'];

  if($action==="Add") 
  {
    $ISBN=$_GET['ISBN'];
    $BuyQuantity=$_GET['txtBuyQty'];
    AddShoppingCart($ISBN,$BuyQuantity);
  }
  elseif($action==="Remove") 
  {
    $ISBN=$_GET['ISBN'];
    Remove($ISBN);
  }
  elseif($action==="Clear") 
  {
    ClearAll();
  }
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Book Store Template, Free CSS Template, CSS Website Layout</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
</html>

<style>
#search-box
{
position: relative;
width: 98%;
margin: 0;
}

#search-form 
{
height: 28px;
border: 1px solid #999;
-webkit-border-radius: 5px;
-moz-border-radius: 5px;
border-radius: 5px;
background-color:#000000;
overflow: hidden;
}

#search-text 
{
font-size: 16px;
color:#ddd;
border-width: 0;
background: transparent;
}

#search-box input[type="text"]
{
width: 90%;
padding: 11px 0 12px 1em;
color:#fff;
outline: none;
}

#search-button {
position: absolute;
top: 0;
right: 0;
height: 29.5px;
width: 80px;
font-size: 14px;
color: #fff;
text-align: center;
line-height: 20px;
border-width: 0;
background-color:#ad4c01;
-webkit-border-radius: 0px 5px 5px 0px;
-moz-border-radius: 0px 5px 5px 0px;
border-radius: 0px 5px 5px 0px;
cursor: pointer;
}

button
{
    background:#FFCC33;
    font-weight: bold;
    width:97px;
    height:40px;
    margin-top:10px;
    margin-bottom:10px;
    font-family: Arial;
    font-size:13;
    border-radius: 6px;
    border-color: grey;
}

input[name=btnContinue]
{
    background: #99CC33;
    font-weight: bold;
    width:103px;
    height:40px;
    border-color:grey;
    border-radius:6px;
}
</style>


<div id="templatemo_container">
  <div id="templatemo_menu">
      <ul>
         <li><a href="Homepage.php" class="current">Home</a></li>
           <li><a href="ShoppingCart.php">My Cart</a></li>
           <li><a href="AboutUs.php">About Us</a></li>
           <li><a href="Contact.php">Contact</a></li>
           <li><a href="Help.php">Help</a></li>
           <li><a href="Logout.php" style="margin-left: 340px">Log Out</a></li>
      </ul>
  </div>
        
  <div id='search-box'>
    <form action='/search' id='search-form' method='get' target='_top'>
      <input id='search-text' placeholder='Search Here...' type='text'/>
      <button id='search-button' type='submit'><span>Search</span></button>
    </form>
  </div>
    

    <div id="templatemo_header">
      <div id="templatemo_special_offers">
          <p>
              <span>25%</span> discounts for
                purchase over $80
            </p>
        <a href="#" style="margin-left: 50px;">Read more...</a>
        </div>
                
        <div id="templatemo_new_books">
          <ul>
                <li>BECOMING</li>
                <li>NORMAL PEOPLE</li>
                <li>THE SADNESS OF BEAUTIFUL THINGS</li>
            </ul>
            <a href="#" style="margin-left: 50px;">Read more...</a>
        </div>
    </div> 
         
<title>Shopping Cart</title>
<body>
<form>
<?php  
if(!isset($_SESSION['ShoppingCart_Function'])) 
{
  echo "<p>Shopping Cart is Empty!</p>";
  exit();
}
?>

<fieldset>
<legend>My Cart</legend>
<table cellpadding="8px">
<tr>
  <th>Image</th>
  <th>ISBN</th>
  <th>Book Name</th>
  <th>Author Name</th>
  <th>Book Type</th>
  <th>Price</th>
  <th>Quantity</th>
  <th>Sub-Total</th>
  <th>Action</th>
</tr>
<?php  
$count=count($_SESSION['ShoppingCart_Function']);

for($i=0;$i<$count;$i++) 
{ 
  $ISBN=$_SESSION['ShoppingCart_Function'][$i]['ISBN'];
  $FrontImage=$_SESSION['ShoppingCart_Function'][$i]['Image'];

  echo "<tr>";
  echo "<td><img src='$FrontImage' width='100' height='100'/></td>";  
  echo "<td>" . $_SESSION['ShoppingCart_Function'][$i]['ISBN'] ."</td>";
  echo "<td>" . $_SESSION['ShoppingCart_Function'][$i]['BookName'] ."</td>";
  echo "<td>" . $_SESSION['ShoppingCart_Function'][$i]['AuthorName'] ."</td>";
  echo "<td>" . $_SESSION['ShoppingCart_Function'][$i]['BookType'] ."</td>";

  echo "<td>" . $_SESSION['ShoppingCart_Function'][$i]['Price'] ." MMK</td>";
  echo "<td>" . $_SESSION['ShoppingCart_Function'][$i]['BuyQuantity'] ." pcs</td>";

  echo "<td>" . $_SESSION['ShoppingCart_Function'][$i]['BuyQuantity'] * $_SESSION['ShoppingCart_Function'][$i]['Price'] ." MMK</td>";
  

  echo "<td><a href='ShoppingCart.php?action=Remove&ISBN=$ISBN'>Remove</a></td>";
  echo "</tr>";
}
?>
</table>
<hr><hr>
<table>
<tr>
  <td>Total:</td>
  <td><b><?php echo CalculateTotalAmount() ?></b> MMK</td>
</tr>
</table>
<table>
    <tr>
      <td>Share</td>
    </tr>
    <tr>
      <td><a href="https://www.facebook.com/bookwormbooksmyanmaronline/" class="fa fa-facebook"></a></td>
      <td><a href="#" class="fa fa-twitter"></a></td>
      <td><a href="Checkout.php" style="margin-left: 630px"><input type="button" name="btnContinue" value="Continue"></td>
    </tr>
    
</table>
</fieldset> 
    <div id="templatemo_footer">
    <p>
      <a href="Homepage.php">Home</a>| <a href="ShoppingCart.php">My Cart</a>|<a href="AboutUs.php">About Us</a>| <a href="Contact.php">Contact</a>| <a href="Help.php">Help</a><br/>
    </p>
    <p>
        Copyright © 2019<p><strong>Bookworm</strong></p>
    </p> 
    </div> 
</form>
</body>
</html>
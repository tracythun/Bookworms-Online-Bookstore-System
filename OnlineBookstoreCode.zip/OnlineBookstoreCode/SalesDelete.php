<?php  
include('connect.php');

$ISBN=$_REQUEST['ISBN'];

$query="DELETE FROM Book WHERE ISBN='$ISBN'";
$result=mysql_query($query);

if($result) //True 
{
	echo "<script>window.alert('Book Successfully Deleted.')</script>";
	echo "<script>window.location='Sales.php'</script>";
}
else
{
	echo "<p>Something wrong in Sales Delete" . mysql_error() . "</p>";
}
?>
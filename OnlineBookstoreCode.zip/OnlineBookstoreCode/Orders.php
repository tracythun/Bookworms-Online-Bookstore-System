<?php 
include ('connect.php');
?>

<html>
<head>
<title>Input Order</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="stylesheet/styles.css" />

<style type="text/css">

body 
{
	background: #333333;
}

.btnSave
{
	background-color:#99FF00;
	color:black;
	font-weight: bold;
	border-radius: 5px;
	width:138px;
	height:30px;
	border-color: grey;
	margin-left: 25px;
	margin-top: 10px;
}

input[name=btnBooks]
{
	background-color:#FFCC00;
    width:125px;
    height:40px;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
    border: 1px solid black;
}

input[name=btnOrders]
{
	background-color:#CC0033;
    width:125px;
    height:40px;
    border: 1px solid black;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
}

input[name=btnDeliveries]
{
	background-color:#FFFF33;
    width:125px;
    height:40px;
    border:1px solid black;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
}

input[name=btnCustomers]
{
	background-color:#3366FF;
    width:125px;
    height:40px;
    border:1px solid black;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
}

input[name=btnSales]
{
	background-color:#33FF66;
    width:125px;
    height:40px;
    border:1px solid black;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
}

input[name=btnReturns]
{
	background-color:#FF3333;
    width:125px;
    height:40px;
    border:1px solid black;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
}

input[name=btnMessages]
{
	background-color: purple;
	width:125px;
    height:40px;
    border:1px solid black;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;	
}

#container
{
    width: 220px;
    height: 440px;
    margin-top: -10px;
    margin-left: -40px;
    background:#CCCCCC;
    border-radius: 3px;
    border: 1px solid black;
    border-radius: 2px;
    font-size:14px;
    font-family: Arial;
}

#templatemo_container
{
	background: #333333;
	height: 100px;
	width: 1353px;
	border:1px solid #FFFFFF;

}

h2
{
   font-family: Arial;
   font-size:16;
   margin-left: 20px;
}

input[name=btnLogout]
{
	background:#FFFF66;
	margin-left: 1170px;
	width: 140px;
	height: 40px;
	border-radius: 5px;
	border:1px solid black;
	font-weight: bold;
	margin-top:-30px;
}

table
{
	margin-left: 200px;
	margin-top: -420px;
}

input[type=text]
{
	margin-top:10px;
	width: 177px;
	height: 22px;
}

th
{
	color:black;
	background:#FFFF66;
	border:1px;
	font-size:13;
	font-family: Arial;
	height:27px;
}

input[name=btnPrint]
{
   background:Purple;
   color:white;
   border-radius: 2px;
   border:1px solid #ccc;
   width: 80px;
}
</style>
</head>

<body>
	<form action="Orders.php">
	<div id="templatemo_container" style="margin-left: -10px">
	  <br/>
	  <br/><h2>ADMIN SITE</h2>
	  <a href="Logout.php"><input type="button" name="btnLogout" value="Logout"></a>
	</div>
    
    <div id="container" style="margin-top: 0px">
        <ul>
         	<li><a href="BookInput.php"><input type="button" name="btnBooks" value="Books"></a></li>
        	<li><a href="Orders.php"><input type="button" name="btnOrders" value="Orders"></a></li>
        	<li><a href="Deliveries.php"><input type="button" name="btnDeliveries" value="Deliveries"></a></li>
        	<li><a href="Customers.php"><input type="button" name="btnCustomers" value="Customers"></a></li>
        	<li><a href="Sales.php"><input type="button" name="btnSales" value="Sales"></a></li>
        	<li><a href="Returns.php"><input type="button" name="btnReturns" value="Returns"></a></li>
        	<li><a href="Messages.php"><input type="button" name="btnMessages" value="Messages"></a></li>
        </ul>
   	</div>				

	<table>
		<tr>
			<td><h4>Order Report</h4></td>
		</tr>
	</table>
	</form>

	<table width="50%" border="1" cellpadding="1px" style="margin-top: 20px">
		<tr>
			<th>Status</th>
			<th>Order ID</th>
			<th>ISBN</th>
			<th>Order Date</th>
			<th>Customer ID</th>
			<th>Quantity</th>
			<th>Price</th>
			<th>Address</th>
			<th>Phone No.</th>
			<th>Actions</th>
		</tr>
		<?php
			$query="SELECT * FROM Order1,OrderDetail";
			$ret=mysql_query($query);
			$count=mysql_num_rows($ret);

			for($i=0;$i<$count;$i++)	
			{
				$data=mysql_fetch_array($ret);
				$OrderID=$data['OrderID'];
				echo "<tr>";
				$pID= $data['OrderID'];
					echo "<td>".$data['Status']."</td>";
					echo "<td>".$data['OrderID']."</td>";
					echo "<td>".$data['ISBN']."</td>";
					echo "<td>".$data['OrderDate']."</td>";
					echo "<td>".$data['CustomerID']."</td>";
					echo "<td>".$data['Quantity']."</td>";
					echo "<td>".$data['Price']."</td>";	
					echo "<td>".$data['Address']."</td>";
					echo "<td>".$data['PhoneNumber']."</td>";	
					echo "<td>
			  		<a href='OrderDelete.php?OrderID=$OrderID'>Delete</a>
					</td>";
				echo "</tr>";
			}
		?>
    </table>

	<br/>
	<!--Print Button ___________________________________-->
	<script>var pfHeaderImgUrl = '';var pfHeaderTagline = 'Order%20Report';var pfdisableClickToDel = 0;var pfHideImages = 0;var pfImageDisplayStyle = 'right';var pfDisablePDF = 0;var pfDisableEmail = 0;var pfDisablePrint = 0;var pfCustomCSS = '';var pfBtVersion='1';(function(){var js, pf;pf = document.createElement('script');pf.type = 'text/javascript';if('https:' == document.location.protocol){js='https://pf-cdn.printfriendly.com/ssl/main.js'}else{js='http://cdn.printfriendly.com/printfriendly.js'}pf.src=js;document.getElementsByTagName('head')[0].appendChild(pf)})();</script>
		<a href="http://www.printfriendly.com" style="color:#6D9F00;text-decoration:none; margin-left: 200px" class="printfriendly" onClick="window.print();return false;" title="Printer Friendly and PDF"><img style="border:none;-webkit-box-shadow:none;box-shadow:none;" src="http://cdn.printfriendly.com/button-print-grnw20.png" alt="Print Friendly and PDF"/></a>
	<!--Print Button ___________________________________-->
</body>
</html>
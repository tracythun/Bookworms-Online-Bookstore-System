<?php  
include('connect.php');

$DeliveryNo=$_REQUEST['DeliveryNo'];

$query="DELETE FROM Delivery WHERE DeliveryNo='$DeliveryNo'";
$result=mysql_query($query);

if($result) //True 
{
	echo "<script>window.alert('Delivery Successfully Deleted.')</script>";
	echo "<script>window.location='Deliveries.php'</script>";
}
else
{
	echo "<p>Something wrong in Delivery Delete" . mysql_error() . "</p>";
}
?>
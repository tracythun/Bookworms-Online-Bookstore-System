-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 25, 2019 at 05:18 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlinebookdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE IF NOT EXISTS `book` (
  `Image` varchar(255) NOT NULL,
  `ISBN` varchar(50) NOT NULL,
  `BookName` varchar(100) NOT NULL,
  `AuthorName` varchar(50) NOT NULL,
  `BookType` varchar(30) NOT NULL,
  `Description` varchar(500) NOT NULL,
  `Price` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`Image`, `ISBN`, `BookName`, `AuthorName`, `BookType`, `Description`, `Price`, `Quantity`) VALUES
('BookImages/_templatemo_image_01.jpg', 'C-7768992', 'Sunflower', 'Parker', 'Flowers', 'For those who wants to plant or love to know about sunflowers, read Sunflower by Parker ', 3000, 6),
('BookImages/_cooking.jpg', 'D-1222001', 'Cooking', 'Gary', 'Cooking', 'It is a book to cook.', 12000, 5);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `CustomerID` int(20) NOT NULL,
  `FirstName` varchar(20) NOT NULL,
  `LastName` varchar(20) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Password` varchar(28) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`CustomerID`, `FirstName`, `LastName`, `Email`, `Password`) VALUES
(1, 'Mandy', 'Butterworth', 'butter@gmail.com', 'jambutter'),
(2, 'Tracy', 'Thun', 'thuntracy@gmail.com', 'TT21720!!');

-- --------------------------------------------------------

--
-- Table structure for table `delivery`
--

CREATE TABLE IF NOT EXISTS `delivery` (
  `DeliveryNo` int(11) NOT NULL,
  `OrderID` int(11) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `PhoneNo` varchar(40) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `delivery`
--

INSERT INTO `delivery` (`DeliveryNo`, `OrderID`, `Address`, `PhoneNo`) VALUES
(3, 2, 'No.8, Pyay Road, Sanchaung township', '09-923344332');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `FirstName` varchar(20) NOT NULL,
  `LastName` varchar(20) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Message` varchar(555) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`FirstName`, `LastName`, `Email`, `Message`) VALUES
('Tracy', 'Thun', 'thuntracy@gmail.com', 'I want to order more books.');

-- --------------------------------------------------------

--
-- Table structure for table `order1`
--

CREATE TABLE IF NOT EXISTS `order1` (
  `OrderID` int(20) NOT NULL,
  `OrderDate` date NOT NULL,
  `CustomerID` varchar(20) NOT NULL,
  `Status` varchar(20) NOT NULL,
  `TotalQuantity` int(11) NOT NULL,
  `TotalAmount` int(11) NOT NULL,
  `PhoneNumber` varchar(40) NOT NULL,
  `Address` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order1`
--

INSERT INTO `order1` (`OrderID`, `OrderDate`, `CustomerID`, `Status`, `TotalQuantity`, `TotalAmount`, `PhoneNumber`, `Address`) VALUES
(5, '2019-04-25', '1', 'Pending', 2, 24000, '09-923344332', 'No.8, Pyay Road, Sanchaung township');

-- --------------------------------------------------------

--
-- Table structure for table `orderdetail`
--

CREATE TABLE IF NOT EXISTS `orderdetail` (
  `ISBN` varchar(40) NOT NULL,
  `Price` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderdetail`
--

INSERT INTO `orderdetail` (`ISBN`, `Price`, `Quantity`) VALUES
('D-1222001', 12000, 2),
('D-1222001', 12000, 2),
('C-7768992', 3000, 2),
('D-1222001', 12000, 2);

-- --------------------------------------------------------

--
-- Table structure for table `returnbooks`
--

CREATE TABLE IF NOT EXISTS `returnbooks` (
  `ISBN` varchar(40) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `CustomerID` int(11) NOT NULL,
  `CustomerName` varchar(20) NOT NULL,
  `Reason` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `returnbooks`
--

INSERT INTO `returnbooks` (`ISBN`, `Quantity`, `CustomerID`, `CustomerName`, `Reason`) VALUES
('C-7768992', 1, 1, 'Mandy Butterworth', 'One paper missing');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE IF NOT EXISTS `staff` (
  `StaffID` int(11) NOT NULL,
  `FirstName` varchar(20) NOT NULL,
  `LastName` varchar(20) NOT NULL,
  `DOB` date NOT NULL,
  `Position` varchar(50) NOT NULL,
  `Phone` varchar(25) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(28) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`StaffID`, `FirstName`, `LastName`, `DOB`, `Position`, `Phone`, `Email`, `Password`) VALUES
(3, 'Rothy', 'Stars', '1998-11-17', 'receptionist', '09-92334341', 'rothy@gmail.com', 'starsangel'),
(4, 'Suzan', 'Boyle', '1994-02-03', 'marketing', '09-422399288', 'suzan99@gmail.com', 'suzan24');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`ISBN`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`CustomerID`);

--
-- Indexes for table `delivery`
--
ALTER TABLE `delivery`
  ADD PRIMARY KEY (`DeliveryNo`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`Email`);

--
-- Indexes for table `order1`
--
ALTER TABLE `order1`
  ADD PRIMARY KEY (`OrderID`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`StaffID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `CustomerID` int(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `delivery`
--
ALTER TABLE `delivery`
  MODIFY `DeliveryNo` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `order1`
--
ALTER TABLE `order1`
  MODIFY `OrderID` int(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `StaffID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php  
include('connect.php');

$ISBN=$_REQUEST['ISBN'];

$query="DELETE FROM returnbooks WHERE ISBN='$ISBN'";
$result=mysql_query($query);

if($result) //True 
{
	echo "<script>window.alert('Return Successfully Deleted.')</script>";
	echo "<script>window.location='Returns.php'</script>";
}
else
{
	echo "<p>Something wrong in Return Delete" . mysql_error() . "</p>";
}
?>
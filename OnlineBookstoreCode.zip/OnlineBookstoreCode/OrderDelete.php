<?php  
include('connect.php');

$OrderID=$_REQUEST['OrderID'];

$query="DELETE FROM Order1 WHERE OrderID='$OrderID'";
$result=mysql_query($query);

if($result) //True 
{
	echo "<script>window.alert('Order Successfully Deleted.')</script>";
	echo "<script>window.location='Orders.php'</script>";
}
else
{
	echo "<p>Something wrong in OrderDelete" . mysql_error() . "</p>";
}
?>
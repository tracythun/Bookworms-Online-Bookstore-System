<?php 
     include ('connect.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Book Store Template, Free CSS Template, CSS Website Layout</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script>
// When the user clicks on <div>, open the popup
function myFunction() {
  var popup = document.getElementById("myPopup");
  popup.classList.toggle("show");
}
</script>
</head>
</html>

<style>
#search-box
{
position: relative;
width: 98%;
margin: 0;
}

#search-form 
{
height: 28px;
border: 1px solid #999;
-webkit-border-radius: 5px;
-moz-border-radius: 5px;
border-radius: 5px;
background-color:#000000;
overflow: hidden;
}

#search-text 
{
font-size: 16px;
color:#ddd;
border-width: 0;
background: transparent;
}

#search-box input[type="text"]
{
width: 90%;
padding: 11px 0 12px 1em;
color:#fff;
outline: none;
}

#search-button {
position: absolute;
top: 0;
right: 0;
height: 29.5px;
width: 80px;
font-size: 14px;
color: #fff;
text-align: center;
line-height: 20px;
border-width: 0;
background-color:#ad4c01;
-webkit-border-radius: 0px 5px 5px 0px;
-moz-border-radius: 0px 5px 5px 0px;
border-radius: 0px 5px 5px 0px;
cursor: pointer;
}

input[name=btnDetail]
{
    background:#FFCC00;
    color: white;
    font-weight: bold;
    width:96px;
    height:20px;
    margin-top:10px;
    margin-bottom:10px;
    font-family: Arial;
    font-size:13;
    border-radius: 6px;
    border-color: grey;
}

.popup {
  position: relative;
  display: inline-block;
  cursor: pointer;
}

.popup .popuptext {
  visibility: hidden;
  width: 160px;
  background-color:white;
  color: black;
  text-align: center;
  border-radius: 6px;
  padding: 8px 0;
  position: absolute;
  z-index: 1;
  bottom: 125%;
  left: 50%;
  margin-left: -80px;
}

.popup .popuptext::after {
  content: "";
  position: absolute;
  top: 100%;
  left: 50%;
  margin-left: -5px;
  border-width: 5px;
  border-style: solid;
  border-color: #555 transparent transparent transparent;
}

.popup .show {
  visibility: visible;
  -webkit-animation: fadeIn 1s;
  animation: fadeIn 1s
}

@-webkit-keyframes fadeIn {
  from {opacity: 0;} 
  to {opacity: 1;}
}

@keyframes fadeIn {
  from {opacity: 0;}
  to {opacity:1 ;}
}

</style>

<div id="templatemo_container">
    <div id="templatemo_menu">
        <ul>
           <li><a href="Homepage.php" class="current">Home</a></li>
           <li><a href="ShoppingCart.php">My Cart</a></li>  
           <li><a href="AboutUs.php">About Us</a></li>
           <li><a href="Contact.php">Contact</a></li>
           <li><a href="Help.php">Help</a></li>
           <li><a href="Logout.php" style="margin-left:350px">Log Out</a></li>

        </ul>
    </div>
        
    <div id='search-box'>
        <form action='/search' id='search-form' method='get' target='_top'>
        <input id='search-text' placeholder='Search Here...' type='text'/>
        <button id='search-button' type='submit'><span>Search</span></button>
        </form>
    </div>
    
    <div id="templatemo_header">
        <div id="templatemo_special_offers">
            <p>
                <span>25%</span> discounts for
                purchase over $80
            </p>
            <div class="popup" onclick="myFunction()" style="margin-left: 50px;">Read More...<span class="popuptext" id="myPopup">Discount will be given when purchase is over $80. Discount will not be valid for new books. </span>
            </div>
        </div>
        
        <div id="templatemo_new_books">
            <ul>
                <li>BECOMING</li>
                <li>NORMAL PEOPLE</li>
                <li>THE SADNESS OF BEAUTIFUL THINGS</li>
            </ul>
            <a href="#" style="margin-left: 50px;">Read more...</a>
          </div>
    </div> 

    <div id="templatemo_content">
        <div id="templatemo_content_left">
          <div class="templatemo_content_left_section">
           <h1>Categories</h1>
            <ul>
              <li>
              <?php  
              $query="SELECT * FROM Book";
              $result=mysql_query($query);
              $count=mysql_num_rows($result);
              ?>
              <?php  
              for ($i=0;$i<$count;$i++) 
              { 
                $array=mysql_fetch_array($result);

              $BookType=$array['BookType'];
              echo "<tr>";
              echo "<td><li><a href='categories.php?BookType=$BookType'>$BookType</li></td>";
              echo "</tr>";
              }
              ?></li>
            </ul>
          </div>
            
            <div class="templatemo_content_left_section">
                <h1>Bestsellers</h1>
                <ul>
                    <li><a href="#">> Becoming</a></li>                         
                    <li><a href="#">> Be Like the Fox: Machiavelli's Lifelong Quest for Freedom</a></li>    
                    <li><a href="#">> Cracking the Coding Interview</a></li>
                    <li><a href="#">> Dirtcandy</a></li>
                    <li><a href="#">> How to Win Friends & Influence People</a></li>                    
                    <li><a href="#">> In Defense of Food: An Eater's Manifesto</a></li>
                    <li><a href="#">> The Wicked King</a></li>
                    <li><a href="#">> Ulysses</a></li>
                </ul>              
            </div>
            
            <p>Share</p>
            <a href="https://www.facebook.com/bookwormbooksmyanmaronline/" class="fa fa-facebook"></a>
            <a href="#" class="fa fa-twitter"></a>
          
        </div> <!-- end of content left -->
    </div>
    
        <table cellspacing="20px">
            <?php
            $query1="SELECT * FROM Book";
            $result1=mysql_query($query1);
            $count1=mysql_num_rows($result1);

            for($a=0;$a<$count1;$a+=2)    
            {
               $query2="SELECT * FROM Book
                        LIMIT $a,2";
                $result2=mysql_query($query2);
                $count2=mysql_num_rows($result2);

                echo "<tr>";
                  for ($b=0;$b<$count2;$b++) 
                  { 
                      $array=mysql_fetch_array($result1);
                      $ISBN=$array['ISBN'];
            ?>  
            <td><img src="<?php echo $array['Image'] ?>" width="150" height="150"/></td>
            <td><b><?php echo $array['BookName'] ?></b><p>
            <b><?php echo $array['Price'] ?></b> MMK
            <a href="BookDetail.php?ISBN=<?php echo $ISBN?>"><input type="button" name="btnDetail" value="Detail"></a></td>
            

            <?php
             }
             echo "</tr>";
            }
            ?>
         </table>
        
    <div id="templatemo_footer">
    <p>
        <a href="Homepage.php">Home</a>| <a href="ShoppingCart.php">My Cart</a>|<a href="AboutUs.php">About Us</a>|<a href="Contact.php">Contact</a>| <a href="Help.php">Help</a><br/>
    </p>
    <p>
        Copyright © 2019<p><strong>Bookworm</strong></p>
    </p> 
    </div> 
</div>
</body>
</html>

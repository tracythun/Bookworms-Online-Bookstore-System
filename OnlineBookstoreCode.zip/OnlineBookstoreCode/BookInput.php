<?php 
session_start();
include ('connect.php');
	
if(isset($_POST['btnSave']))
{
  $ISBN=$_POST['txtISBN'];  
  $BookName=$_POST['txtBookName'];
  $AuthorName=$_POST['txtAuthorName'];
  $BookType=$_POST['txtBookType'];
  $Description=$_POST['txtDescription'];
  $Price=$_POST['txtPrice'];
  $Quantity=$_POST['txtQuantity'];

 $image1=$_FILES['txtimage']['name'];
 $folder="BookImages/";
 if($image1)
{
	$filename=$folder."_".$image1;
	$copied=copy($_FILES['txtimage']['tmp_name'],$filename);
	if(!$copied)
	{
		exit ("Problem occurred. Cannot Upload Image");
	}
}
	
		$checkBook="SELECT * FROM Book
		 			Where BookName='$txtBookName'";
		$result=mysql_query($checkBook);
		$count=mysql_num_rows($result);
	
		if ($count!=0)
		{
			echo "<script>window.alert('BookName $txtBookName already exist in Database.')</script>";
			echo "<script>window.location='BookInput.php'</script>";
			exit();
		}

		$query="INSERT INTO Book
				(`Image`,`ISBN`,`BookName`, `AuthorName`, `BookType`,`Description`,`Price`,`Quantity`) 
				VALUES 
				('$filename','$ISBN','$BookName','$AuthorName','$BookType','$Description','$Price','$Quantity')";

		$result=mysql_query($query);

		if($result)
		{
			echo "<script>window.alert('Input successful!!')</script>";
			echo "<script>window.location='BookInput.php'</script>";
		}
		else
		{
			echo "<p>Error in Book Input." .mysql_error()."</p>";
		}
	}	
?>

<html>
<head>
<title>Book Input</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="stylesheet/styles.css" />

<style type="text/css">
body 
{
	background: #333333;
}

input[type=submit]
{
	background-color:#99FF00;
	color:black;
	font-weight: bold;
	border-radius: 5px;
	width:138px;
	height:30px;
	border-color: grey;
	margin-left: 25px;
	margin-top: 10px;

}

input[name=btnBooks]
{
	background-color:#FFCC00;
    width:125px;
    height:40px;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
    border: 1px solid black;
}

input[name=btnOrders]
{
	background-color:#CC0033;
    width:125px;
    height:40px;
    border: 1px solid black;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
}

input[name=btnDeliveries]
{
	background-color:#FFFF33;
    width:125px;
    height:40px;
    border:1px solid black;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
}

input[name=btnCustomers]
{
	background-color:#3366FF;
    width:125px;
    height:40px;
    border:1px solid black;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
}

input[name=btnSales]
{
	background-color:#33FF66;
    width:125px;
    height:40px;
    border:1px solid black;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
}

input[name=btnReturns]
{
	background-color:#FF3333;
    width:125px;
    height:40px;
    border:1px solid black;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
}

input[name=btnMessages]
{
	background-color:purple;
    width:125px;
    height:40px;
    border:1px solid black;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
}


#container
{
    width: 220px;
    height: 440px;
    margin-top: -10px;
    margin-left: -40px;
    background:#CCCCCC;
    border-radius: 3px;
    border: 1px solid black;
    border-radius: 2px;
    font-size:14px;
    font-family: Arial;
}

#templatemo_container
{
	background: #333333;
	height: 100px;
	width: 1353px;
	border:1px solid #FFFFFF;
}

h2
{
   font-family: Arial;
   font-size:16;
   margin-left: 20px;
}

input[name=btnLogout]
{
	background:#FFFF66;
	margin-left: 1170px;
	width: 140px;
	height: 40px;
	border-radius: 5px;
	border:1px solid black;
	font-weight: bold;
	margin-top:-30px;
}

table
{
	margin-left: 200px;
	margin-top: -420px;
}

input[type=text]
{
	margin-top:10px;
	width: 177px;
	height: 22px;
}

th
{
    color:black;
	background:#FFFF66;
	border:1px;
	font-size:13;
	font-family: Arial;
	height:27px;
}

input[type=number]
{
	margin-top:10px;
	width:177px;
	height:22px;
}

</style>
</head>

<body>

	<form action="BookInput.php" method="post" enctype="multipart/form-data">

	<div id="templatemo_container" style="margin-left: -10px">
	<br/>
	<br/><h2>ADMIN SITE</h2>
	<a href="Logout.php"><input type="button" name="btnLogout" value="Logout"></a>	
	</div>
    
    <div id="container" style="margin-top: 0px">
        <ul>
        	<li><a href="BookInput.php"><input type="button" name="btnBooks" value="Books"></a></li>
        	<li><a href="Orders.php"><input type="button" name="btnOrders" value="Orders"></a></li>
        	<li><a href="Deliveries.php"><input type="button" name="btnDeliveries" value="Deliveries"></a></li>
        	<li><a href="Customers.php"><input type="button" name="btnCustomers" value="Customers"></a></li>
        	<li><a href="Sales.php"><input type="button" name="btnSales" value="Sales"></a></li>
        	<li><a href="Returns.php"><input type="button" name="btnReturns" value="Returns"></a></li>
        	<li><a href="Messages.php"><input type="button" name="btnMessages" value="Messages"></a></li>
        </ul>
   	</div>  

	<table>
		<tr>
			<td><h4>Books</h4></td>
		</tr>
		<tr>
		   <td>Image</td>
		   <td><input type="file" name="txtimage" required></td>
		</tr>

		<tr>
			<td>ISBN</td>
			<td><input type="text" name="txtISBN"></td>
		</tr>

		<tr>
			<td>Book Name</td>
			<td><input type="text" name="txtBookName"></td>
		</tr>

		<tr>
			<td>Author Name</td>
			<td><input type="text" name="txtAuthorName"></td>
		</tr>

		<tr>
		    <td>Book Type</td>
			<td><input type="text" name="txtBookType"></td>
		</tr>	

		<tr>
		    <td>Description</td>
			<td><input type="text" name="txtDescription"></td>
		</tr>	

		<tr>
			<td>Price</td>
			<td><input type="text" name="txtPrice"></td>
		</tr>

		<tr>
			<td>Quantity</td>
			<td><input type="number" name="txtQuantity" min="0"></td>
		<tr>
			<td>
			</td>
			<td>
			<input type="submit" name="btnSave" value="Save"/>

			</td>
		</tr>
	</table>
	</form>

<?php  
$query="SELECT * FROM Book";
$result=mysql_query($query);
$count=mysql_num_rows($result);

if($count<1) 
{
	echo "<p>No BookData Found.</p>";
	exit();
}
?>

<table width="50%" border="1" cellpadding="1px" style="margin-top: 20px">
<tr>
	<th>Image</th>
	<th>ISBN</th>
	<th>Book Name</th>
	<th>Author Name</th>
	<th>Book Type</th>
	<th>Description</th>
	<th>Price</th>
	<th>Quantity</th>
	<th>Actions</th>
</tr>

<?php
$query="SELECT * FROM Book";
$ret=mysql_query($query);
$count=mysql_num_rows($ret);

for($i=0;$i<$count;$i++)	
	{
		$data=mysql_fetch_array($ret);
		$ISBN=$data['ISBN'];
		echo "<tr>";
			echo "<td><img src='".$data['Image']."' width='100px' height='100px'></td>";
			echo "<td>".$data['ISBN']."</td>";
			echo "<td>".$data['BookName']."</td>";
			echo "<td>".$data['AuthorName']."</td>";
			echo "<td>".$data['BookType']."</td>";
			echo "<td>".$data['Description']."</td>";
			echo "<td>".$data['Price']."</td>";
			echo "<td>".$data['Quantity']."</td>";
			echo "<td>
			  <a href='BookUpdate.php?ISBN=$ISBN'>Edit</a>
			  <a href='BookDelete.php?ISBN=$ISBN'>Delete</a>
			</td>";
		echo "</tr>";
	}
?>	
</table>
</form>
</body>
</html>
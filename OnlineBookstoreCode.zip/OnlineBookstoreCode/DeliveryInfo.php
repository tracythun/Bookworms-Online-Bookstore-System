<?php  
session_start(); 
include('connect.php'); 

if(isset($_POST['btnOrder']))
{
  $Address=$_POST['txtAddress'];  
  $State=$_POST['txtState'];
  $ZipCode=$_POST['txtZipCode'];
  $City=$_POST['txtCity'];
  $PhoneNumber=$_POST['txtPhoneNumber'];

   $checkDelivery="SELECT * FROM Delivery
          Where DeliveryNo.='$txtDeliveryNo.'";
    $result=mysql_query($checkBook);
    $count=mysql_num_rows($result);
  
    if ($count!=0)
    {
      echo "<script>window.alert('DeliveryNo. $txtDeliveryNo. already exist in Database.')</script>";
      echo "<script>window.location='Checkout.php'</script>";
      exit();
    }

    $query="INSERT INTO Delivery
        (`Address`,`State`,`ZipCode`, `City`, `PhoneNumber`) 
        VALUES 
        ('$Address','$State','$ZipCode','$City','PhoneNumber')";

    $result=mysql_query($query);

    if($result)
    {
      echo "<script>window.alert('Checkout successful!!')</script>";
      echo "<script>window.location='Homepage.php'</script>";
    }
    else
    {
      echo "<p>Error in Checkout." .mysql_error()."</p>";
    }
  } 

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Book Store Template, Free CSS Template, CSS Website Layout</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- Add font awesome icons -->

</head>
</html>
<style>
#search-box
{
position: relative;
width: 100%;
margin: 0;
}

#search-form 
{
height: 28px;
border: 1px solid #999;
-webkit-border-radius: 5px;
-moz-border-radius: 5px;
border-radius: 5px;
background-color:#000000;
overflow: hidden;
}

#search-text 
{
font-size: 16px;
color:#ddd;
border-width: 0;
background: transparent;
}

#search-box input[type="text"]
{
width: 90%;
padding: 11px 0 12px 1em;
color:#fff;
outline: none;
}

#search-button {
position: absolute;
top: 0;
right: 0;
height: 29.5px;
width: 80px;
font-size: 14px;
color: #fff;
text-align: center;
line-height: 20px;
border-width: 0;
background-color:#ad4c01;
-webkit-border-radius: 0px 5px 5px 0px;
-moz-border-radius: 0px 5px 5px 0px;
border-radius: 0px 5px 5px 0px;
cursor: pointer;
}

button
{
  background:#FFCC33;
  width: 140px;
  height: 40px;
  border:1px solid #666666;
  font-weight:bold;
  border-radius: 7px;
  margin-left: 480px;
  margin-bottom: 20px;
}

input[type=submit]
{
  background:#CCFF33;  
  border:1px solid #ccc;
  width: 120px;
  height: 35px;
  font-weight: bold;
  border-radius: 7px;
  margin-top: 10px;
}


#container
{  
  background:#FFFF66;
  color:black;
  width: 212px;
  height: 182px;
  margin-left: 50px;
  border-color:grey;
  font-family: Arial;
  font-size: 13px;
}

.fa 
{
  padding: 10px;
  font-size: 30px;
  width: 30px;
  text-align: center;
}

input[type=text]
{
  background: #666666;
  width: 169px;
  height: 37px;
  border: 1px solid black;
  font-family: Arial;
  margin-top: 10px;
  color:white;
  font-size: 14px;
}

textarea
{
  background: #666666;
  border: 1px solid black;
  width: 343px;
  height: 92px;
  color:white;
  font-size:14px;
  font-family: Arial;
}

::placeholder 
{
  color:white;
}

textarea[placeholder="City"]
{
  color:white;
  font-size:14px;
  font-family: Arial;
  width: 343px;
  height: 37px;
  margin-top: 10px;
}
</style>


<div id="templatemo_container">
  <div id="templatemo_menu">
      <ul>
         <li><a href="Homepage.php" class="current">Home</a></li>
           <li><a href="Shop.php">Shop</a></li>  
           <li><a href="MyAccount.php">My Account</a></li>
           <li><a href="AboutUs.php">About Us</a></li>
           <li><a href="Contact.php">Contact</a></li>
           <li><a href="Help.php">Help</a></li>
      </ul>
  </div>
      
  <div id='search-box'>
    <form action='/search' id='search-form' method='get' target='_top'>
      <input id='search-text' placeholder='Search Here...' type='text'/>
      <button id='search-button' type='submit'><span>Search</span></button>
     </form>
  </div>
    

    <div id="templatemo_header">
      <div id="templatemo_special_offers">
        <p>
          <span>25%</span> discounts for
        purchase over $80
        </p>
    <a href="subpage.html" style="margin-left: 50px;">Read more...</a>
        </div>
        
        
        <div id="templatemo_new_books">
          <ul>
                <li>BECOMING</li>
                <li>NORMAL PEOPLE</li>
                <li>THE SADNESS OF BEAUTIFUL THINGS</li>
            </ul>
            <a href="subpage.html" style="margin-left: 50px;">Read more...</a>
        </div>
    </div> 
            <br>


        <div id="container">
          <table>
          <h3 align="center">Checkout Info:</h3>
          <tr>
            <td>Quantity</td>
            <td>...MMK</td>
          </tr>
          <tr>
            <td>Total</td>
            <td>..MMK</td>
          </tr>
          </table>
        </div>

        <div id="templatemo_product_box" style="margin-left: 50px">     
              <table align="center" style="margin-top:-195px">
              <tr> 
                <td><h3>Fill in information for delivery: </h3></td>
              </tr>
              <tr>         
                <td><textarea placeholder="Address" name="txtAddress"></textarea></td>
              </tr>
              <tr>
                <td><input type="text" placeholder="State" name="txtState"></td>
                <td><input type="text" placeholder="Zip Code" style="margin-left: -175px" name="txtZipCode"></td>
              </tr>
              <tr>                                                        
                <td><textarea placeholder="City" name="txtCity"></textarea></td>
              </tr>
              <tr>
                <td><input type="text" placeholder="Phone Number" name="txtPhoneNumber"></td>
              </tr>
              <tr>            
                <td><input type="submit" name="btnOrder" value="Order"></td>
              </tr>
            </table>  
          
          <h3>Share</h3>
          <br/>
          <a href="www.facebook.com" class="fa fa-facebook"></a>
          <a href="www.twitter.com" class="fa fa-twitter"></a>
       </div>
       <br/>
    <div id="templatemo_footer">  
    <p>
      <a href="Homepage.php">Home</a>| <a href="Shop.php">Shop</a>| <a href="MyAccount.php">My Account</a>| <a href="AboutUs.php">About Us</a>| <a href="Contact.php">Contact</a>| <a href="Help.php">Help <br/></a>
    </p>
    <p>
         Copyright © 2019<strong>Bookworm</strong></a> 
    </p> 
    </div> 
</body>
</html>


          
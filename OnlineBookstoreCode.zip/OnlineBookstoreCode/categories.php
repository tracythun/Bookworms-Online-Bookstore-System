<?php 
     include ('connect.php');

if(isset($_GET['BookType']))
{
  $BookType=$_GET['BookType'];
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Book Store Template, Free CSS Template, CSS Website Layout</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script>
// When the user clicks on <div>, open the popup
function myFunction() {
  var popup = document.getElementById("myPopup");
  popup.classList.toggle("show");
}
</script>
</head>
</html>

<style>
#search-box
{
position: relative;
width: 98%;
margin: 0;
}

#search-form 
{
height: 28px;
border: 1px solid #999;
-webkit-border-radius: 5px;
-moz-border-radius: 5px;
border-radius: 5px;
background-color:#000000;
overflow: hidden;
}

#search-text 
{
font-size: 16px;
color:#ddd;
border-width: 0;
background: transparent;
}

#search-box input[type="text"]
{
width: 90%;
padding: 11px 0 12px 1em;
color:#fff;
outline: none;
}

#search-button {
position: absolute;
top: 0;
right: 0;
height: 29.5px;
width: 80px;
font-size: 14px;
color: #fff;
text-align: center;
line-height: 20px;
border-width: 0;
background-color:#ad4c01;
-webkit-border-radius: 0px 5px 5px 0px;
-moz-border-radius: 0px 5px 5px 0px;
border-radius: 0px 5px 5px 0px;
cursor: pointer;
}

input[name=btnDetail]
{
    background:#FFCC00;
    color: white;
    font-weight: bold;
    width:96px;
    height:20px;
    margin-top:10px;
    margin-bottom:10px;
    font-family: Arial;
    font-size:13;
    border-radius: 6px;
    border-color: grey;
}

</style>

<div id="templatemo_container">
    <div id="templatemo_menu">
        <ul>
           <li><a href="Homepage.php" class="current">Home</a></li>
           <li><a href="ShoppingCart.php">My Cart</a></li>  
           <li><a href="AboutUs.php">About Us</a></li>
           <li><a href="Contact.php">Contact</a></li>
           <li><a href="Help.php">Help</a></li>
           <li><a href="Logout.php" style="margin-left:350px">Log Out</a></li>

        </ul>
    </div>
        
    <div id='search-box'>
        <form action='/search' id='search-form' method='get' target='_top'>
        <input id='search-text' placeholder='Search Here...' type='text'/>
        <button id='search-button' type='submit'><span>Search</span></button>
        </form>
    </div>
    
    <div id="templatemo_content">

  <?php echo $BookType?>

    </div>
    
        <table cellspacing="20px">
            <?php
            $query1="SELECT * FROM Book
            WHERE BookType='$BookType'";

            $result1=mysql_query($query1);
            $count1=mysql_num_rows($result1);

            for($a=0;$a<$count1;$a+=2)    
            {
               $query2="SELECT * FROM Book
                        WHERE BookType='$BookType'
                        LIMIT $a,2";
                $result2=mysql_query($query2);
                $count2=mysql_num_rows($result2);

                echo "<tr>";
                  for ($b=0;$b<$count2;$b++) 
                  { 
                      $array=mysql_fetch_array($result1);
                      $ISBN=$array['ISBN'];
            ?>  
            <td><img src="<?php echo $array['Image'] ?>" width="150" height="150"/></td>
            <td><b><?php echo $array['BookName'] ?></b><p>
            <b><?php echo $array['Price'] ?></b> MMK
            <p>
            <a href="BookDetail.php?ISBN=<?php echo $ISBN?>"><input type="button" name="btnDetail" value="Detail"></a></td>
            

            <?php
             }
             echo "</tr>";
            }
            ?>
        </table>
        
    <div id="templatemo_footer">
      <p style="margin-left:-800px">Share</p>
      <a href="https://www.facebook.com/bookwormbooksmyanmaronline/" class="fa fa-facebook" style="margin-left:-700px"></a>
      <a href="#" class="fa fa-twitter"></a>
          
   
    <p>
        <a href="Homepage.php">Home</a>| <a href="ShoppingCart.php">My Cart</a>|<a href="AboutUs.php">About Us</a>|<a href="Contact.php">Contact</a>| <a href="Help.php">Help</a><br/>
    </p>
    <p>
        Copyright © 2019<p><strong>Bookworm</strong></p>
    </p> 
    </div> 
</div>
</body>
</html>

<?php
session_start();
include ('connect.php'); 

if(isset($_POST['btnSend']))
{
    $txtFirstName=$_POST['txtFirstName'];
    $txtLastName=$_POST['txtLastName'];
    $txtEmail=$_POST['txtEmail'];
    $txtMessage=$_POST['txtMessage'];

    $checkMessage="SELECT * FROM Messages
        Where Email='$txtEmail'";

    $result=mysql_query($checkMessage);
    $count=mysql_num_rows($result);
    
    if ($count!=0)
    {
        echo "<script>window.alert('Email $txtEmail has already sent a message.')</script>";
        echo "<script>window.location='Contact.php'</script>";
        exit();
    }

    $query="INSERT INTO `Messages`(`FirstName`,`LastName`,`Email`,`Message`)
    VALUES ('$txtFirstName','$txtLastName','$txtEmail','$txtMessage')";

    $result=mysql_query($query);

    if($result)
    {
        echo "<script>window.alert('We'll get back to you within 24 hours.Thanks for your message')</script>";
        echo "<script>window.location='Homepage.php'</script>";  
    }
    else
    {
        echo "<p>Please fill in all the form." . mysql_error() . "</p>";
    }
}
?>
<script>
function myFunction()
{
    var txt;
    var person = prompt("Please enter your name:", "Harry Potter");
    if (person == null || person == "") {
        txt = "User cancelled the prompt.";
    } else {
        txt = "Hello " + person + "! How are you today?";
    }
    document.getElementById("demo").innerHTML = txt;
}
</script>

<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<title>Contact Form</title>
</head>
<style>
html, body 
{   
    width: 100%;   
    height: 100%;   
    font-family: "Helvetica Neue", Helvetica, sans-serif;   
    color: #444;   
    -webkit-font-smoothing: antialiased; background:url(images/border.jpg)no-repeat center;  
}
label
{
    display:block;
    margin-top:20px;
    letter-spacing:2px;
}
input[name="btnSend"]
{
  width:460px;
  height:30px;
  margin-top:20px;
  background: #FF7F50;
  font-weight: bold;
}
.body {
    display:block;
    margin:0 auto;
    width:576px;
}
form {
    margin:0 auto;
    width:459px;
}
input, textarea
{
    width:439px;
    height:27px;
    background:#efefef;
    border:1px solid #dedede;
    padding:10px;
    margin-top:3px;
    font-size:0.9em;
    color:#3a3a3a;
}
textarea 
{
    height:213px;
    font-size:13;
    font-family: Arial;
}
</style>
<body>
    <form action="Contact.php" method="post">
    <header class="body">
    </header>

    <section class="body">
    </section>

    <footer class="body">
    </footer>
    <form>
    <label><h2>Contact Us</h2></label>
            
    <label>First Name</label>
    <input type="name" name="txtFullName" placeholder="Type Here" required/>

    <label>Last Name</label>
    <input type="name" name="txtFullName" placeholder="Type Here" required/>

    <label>Email</label>
    <input type="Email" name="txtEmail" placeholder="Type Here">
            
    <label>Message</label>
    <textarea name="txtMessage" placeholder="Type Here"></textarea>

    <input type="submit" name="btnSend" value="Send"/></a>
</form>
</body>
</html>
<?php
session_start();
if(isset($_SESSION['CustomerID']))
{
	session_unset($_SESSION['CustomerID']);
}
elseif (isset($_SESSION['StaffID'])) 
{
	session_unset($_SESSION['StaffID']);
}
else
{
	session_destroy();

}
echo "<script>
	alert('Session Expired. Login again');
	location.assign('Login.php');
</script>";
?>

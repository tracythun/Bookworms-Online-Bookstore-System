<?php 
session_start();
include ('connect.php');
	
if(isset($_POST['btnSave']))
{ 
  $ISBN=$_POST['txtISBN'];
  $Quantity=$_POST['txtQuantity'];
  $CustomerID=$_POST['txtCustomerID'];
  $CustomerName=$_POST['txtCustomerName'];
  $Reason=$_POST['txtReason'];

  $checkReturn="SELECT * FROM returnbooks
		 			Where ISBN='$txtISBN'";
  $result=mysql_query($checkReturn);
  $count=mysql_num_rows($result);
	
  if ($count!=0)
    {
		echo "<script>window.alert('ISBN $txtISBN already exist in Database.')</script>";
		echo "<script>window.location='Returns.php'</script>";
		exit();
	}

	$query="INSERT INTO returnbooks
			(`ISBN`,`Quantity`,`CustomerID`,`CustomerName`,`Reason`) 
			VALUES 
			('$ISBN','$Quantity','$CustomerID','$CustomerName','$Reason')";

	$result=mysql_query($query);

	if($result)
	{
		echo "<script>window.alert('Input successful!!')</script>";
		echo "<script>window.location='Returns.php'</script>";
	}
	else
	{
		echo "<p>Error in Return Input." .mysql_error()."</p>";
	}
	}	
?>

<html>
<head>
<title>Returns</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="stylesheet/styles.css" />

<style type="text/css">
body 
{
	background: #333333;
}

input[type=submit]
{
	background-color:#99FF00;
	color:black;
	font-weight: bold;
	border-radius: 5px;
	width:138px;
	height:30px;
	border-color: grey;
	margin-left: 25px;
	margin-top: 10px;

}

input[name=btnBooks]
{
	background-color:#FFCC00;
    width:125px;
    height:40px;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
    border: 1px solid black;
}

input[name=btnOrders]
{
	background-color:#CC0033;
    width:125px;
    height:40px;
    border: 1px solid black;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
}

input[name=btnDeliveries]
{
	background-color:#FFFF33;
    width:125px;
    height:40px;
    border:1px solid black;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
}

input[name=btnCustomers]
{
	background-color:#3366FF;
    width:125px;
    height:40px;
    border:1px solid black;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
}

input[name=btnSales]
{
	background-color:#33FF66;
    width:125px;
    height:40px;
    border:1px solid black;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
}

input[name=btnReturns]
{
	background-color:#FF3333;
    width:125px;
    height:40px;
    border:1px solid black;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
}

input[name=btnMessages]
{
	background-color:purple;
    width:125px;
    height:40px;
    border:1px solid black;
    border-radius: 5px;
    margin-bottom: 10px;
    margin-left: 25px;
}


#container
{
    width: 220px;
    height: 440px;
    margin-top: -10px;
    margin-left: -40px;
    background:#CCCCCC;
    border-radius: 3px;
    border: 1px solid black;
    border-radius: 2px;
    font-size:14px;
    font-family: Arial;
}

#templatemo_container
{
	background: #333333;
	height: 100px;
	width: 1353px;
	border:1px solid #FFFFFF;
}

h2
{
   font-family: Arial;
   font-size:16;
   margin-left: 20px;
}

input[name=btnLogout]
{
	background:#FFFF66;
	margin-left: 1170px;
	width: 140px;
	height: 40px;
	border-radius: 5px;
	border:1px solid black;
	font-weight: bold;
	margin-top:-30px;
}

table
{
	margin-left: 200px;
	margin-top: -420px;
}

input[type=text]
{
	margin-top:10px;
	width: 177px;
	height: 22px;
}

th
{
    color:black;
	background:#FFFF66;
	border:1px;
	font-size:13;
	font-family: Arial;
	height:27px;
}

input[type=number]
{
	margin-top:10px;
	width:177px;
	height:22px;
}

</style>
</head>

<body>

	<form action="Returns.php" method="post" enctype="multipart/form-data">

	<div id="templatemo_container" style="margin-left: -10px">
	<br/>
	<br/><h2>ADMIN SITE</h2>
	<a href="Logout.php"><input type="button" name="btnLogout" value="Logout"></a>	
	</div>
    
    <div id="container" style="margin-top: 0px">
        <ul>
        	<li><a href="BookInput.php"><input type="button" name="btnBooks" value="Books"></a></li>
        	<li><a href="Orders.php"><input type="button" name="btnOrders" value="Orders"></a></li>
        	<li><a href="Deliveries.php"><input type="button" name="btnDeliveries" value="Deliveries"></a></li>
        	<li><a href="Customers.php"><input type="button" name="btnCustomers" value="Customers"></a></li>
        	<li><a href="Sales.php"><input type="button" name="btnSales" value="Sales"></a></li>
        	<li><a href="Returns.php"><input type="button" name="btnReturns" value="Returns"></a></li>
        	<li><a href="Messages.php"><input type="button" name="btnMessages" value="Messages"></a></li>
        </ul>
   	</div>  

	<table>
		<tr>
			<td>ISBN</td>
			<td><input type="text" name="txtISBN"></td>
		</tr>

		<tr>
			<td>Quantity</td>
			<td><input type="number" name="txtQuantity"></td>
		</tr>

		<tr>
			<td>Customer ID</td>
			<td><input type="text" name="txtCustomerID"></td>
		</tr>

		<tr>
			<td>Customer Name</td>
			<td><input type="text" name="txtCustomerName"></td>
		</tr>

		<tr>
			<td>Reason</td>
			<td><input type="text" name="txtReason"></td>
		</tr>
	    
	    <tr>
			<td>
			</td>
			<td>
			     <input type="submit" name="btnSave" value="Save"/>
			</td>
		</tr>
	</table>
	</form>

<?php  
$query="SELECT * FROM returnbooks";
$result=mysql_query($query);
$count=mysql_num_rows($result);

if($count<1) 
{
	echo "<p>No Return Data Found.</p>";
	exit();
}
?>

<table width="50%" border="1" cellpadding="1px" style="margin-top: 20px">
<tr>
	<th>ISBN</th>
	<th>Quantity</th>
	<th>Customer ID</th>
	<th>Customer Name</th>
	<th>Reason</th>
	<th>Actions</th>
</tr>

<?php
$query="SELECT * FROM returnbooks";
$ret=mysql_query($query);
$count=mysql_num_rows($ret);

for($i=0;$i<$count;$i++)	
	{
		$data=mysql_fetch_array($ret);
		$ISBN=$data['ISBN'];
		echo "<tr>";
			echo "<td>".$data['ISBN']."</td>";
			echo "<td>".$data['Quantity']."</td>";
			echo "<td>".$data['CustomerID']."</td>";
			echo "<td>".$data['CustomerName']."</td>";			
			echo "<td>".$data['Reason']."</td>";
			echo "<td>
			  <a href='ReturnUpdate.php?ISBN=$ISBN'>Edit|</a>
			  <a href='DeleteReturn.php?ISBN=$ISBN'>Delete</a>
			</td>";
		echo "</tr>";
	}
?>	
</table>
</form>
</body>
</html>
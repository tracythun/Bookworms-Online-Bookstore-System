<?php
session_start();
include ('connect.php'); 

if(isset($_POST['btnLogin']))
{
	$txtEmail=$_POST['txtEmail'];
	$txtPassword=$_POST['txtPassword'];

    function StaffLogin($txtEmail,$txtPassword)
    {
	   $txtEmail=$txtEmail;
	   $txtPassword=$txtPassword;
	
    	$query="SELECT * FROM Staff
	       		WHERE Email='$txtEmail'
			    AND Password='$txtPassword'";

	    $result=mysql_query($query);
	    $count=mysql_num_rows($result);
	    $arr=mysql_fetch_array($result);
	
	    if($count==0) 
	    {
		  // echo "<script>window.alert('Email or Password Incorrect.')</script>";
		  //echo "<script>window.location='Customer_Login.php'</script>";
	    }
	    else
	    {
		  $_SESSION['StaffID']=$arr['StaffID'];
		  $_SESSION['FirstName']=$arr['FirstName'];
		
		  echo "<script>window.alert('Success:You are Login as Admin.')</script>";
		  echo "<script>window.location='BookInput.php'</script>";
	    }
    }		
	
    $query="Select * from Customer
	        where Email='$txtEmail'
		    and Password='$txtPassword'";

	$ret=mysql_query($query,$connection);

	$num_results=mysql_num_rows($ret);
	$row=mysql_fetch_array($ret);
	
	if($num_results<=0) 
	{
		Login($txtEmail,$txtPassword);
	}
	else 
	{
		$_SESSION["Email"]=$row["Email"];
		$_SESSION["CustomerID"]=$row["CustomerID"];

		echo "<script>window.alert('Welcome to Bookworm website!')</script>";
		echo "<script>window.location='Homepage.php'</script>";
	}
}	
?>

<script>
function myFunction()
{
    var txt;
    var person = prompt("Please enter your name:", "Harry Potter");
    if (person == null || person == "") {
        txt = "User cancelled the prompt.";
    } else {
        txt = "Hello " + person + "! How are you today?";
    }
    document.getElementById("demo").innerHTML = txt;
}
</script>

<html>
<head>
    <link rel="stylesheet" type="text/css" href="style.css"/>

<style>
html, body 
{   
    width: 100%;   
    height: 100%;   
    font-family: "Helvetica Neue", Helvetica, sans-serif;   
    color: #444;   
    -webkit-font-smoothing: antialiased; background:url(BookImages/bookworm.jpg)no-repeat center;
}

#container 
{
    position: fixed;
    width: 340px;
    height: 30px;
    top: 50%;
    left: 50%;
    margin-top: -140px;
    margin-left: -170px;
}

a
{
    color:black;
    font-family: "Verdana";
    font-size:12px;
    margin-left: 18px;
    padding-top: 12px;
}

b
{   
    color:black;
    display: inline-block;
    margin-left: 18px;
    padding-top: 12px;
    font-size: 12px;
}
form
{
   margin: 0 auto;
   margin-top: 20px;
}

label 
{
    color: black;
    display: inline-block;
    margin-left: 18px;
    padding-top: 12px;
    font-size: 14px;
}

legend
{
    color:black;
    display: inline-block;
    margin-left: 18px;
    padding-top: 10px;
    font-size: 15px;
}

input 
{
    font-family: "Verdana";
    font-size: 15px;
    outline: none;
}

input[type=email],
input[type=password] 
{
    color: #777;
    padding-left: 10px;
    margin: 10px;
    margin-top: 12px;
    margin-left: 18px;
    width: 290px;
    height: 35px;
}

#lower
{
    background: #ffff66;
    width: 100%;
    height: 80px;
    margin-top: 20px;
}

input[type=submit]
{
    float: right;
    margin-right: 20px;
    margin-top: 20px;
    width: 80px;
    height: 30px;

    background: #fff;
    border-radius: 3px;
    border: 1px solid #ccc;
    box-shadow: 0 1px 2px rgba(0, 0, 0, .1);

}

#container
{
    position: fixed;
    width: 325px;
    height: 324px;
    top: 50%;
    left: 52%;
    margin-top: -140px;
    margin-left: -170px;
    background: #ffff66;
    border-radius: 3px;
    border: 1px solid #ccc;
    box-shadow: 0 1px 2px rgba(0, 0, 0, .1);

    border: 1px solid #04225e;
    border-radius: 2px;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 1px black;
}

input[type=Email] 
{
    color:grey;
    padding-left: 10px;
    margin: 10px;
    margin-top: 12px;
    margin-left: 18px;
    width: 290px;
    height: 35px;
    border: 1px;
    border-radius: 0px;
    box-shadow:  inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 1px #000;
}


input[type=password] 
{
    color: #777;
    padding-left: 10px;
    margin: 10px;
    margin-top: 12px;
    margin-left: 18px;
    width: 290px;
    height: 35px;
    border: 1px;
    border-radius: 0px;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 1px #000;
}


input[type=submit] 
{
    float: left 20px;
    margin-right: 20px;
    margin-top: -30px;
    width: 80px;
    height: 30px;
    font-size: 14px;
    font-weight: bold;
    color:black;
    background-color: #acd6ef; /*IE fallback*/
    background-image: -webkit-gradient(linear, left top, left bottom, from(#aaff00), to(#aaff00));
    background-image: -moz-linear-gradient(top left 90deg, #acd6ef 0%, #6ec2e8 100%);
    background-image: linear-gradient(top left 90deg, #acd6ef 0%, #6ec2e8 100%);
    border-radius: 5px ;
    border: 1px solid grey;
    box-shadow: 0 1px 2px rgba(0, 0, 0, .3), inset 0 1px 0 rgba(255, 255, 255, .5);
    cursor: pointer;
}
</style>
</head>

<form action="Login.php" method="post">
<div id="container">
<legend>Enter Login Info:</legend>
<br/>

	<label>Email</label>
    <input type="Email" name="txtEmail" placeholder="Eg.tuuds@gmail.com" required/>
       	       
    <label>Password</label>
    <input type="password" name="txtPassword" placeholder="XXXXXXXXXXXXXXXXXXXX" required />
        	 
    <div id="lower">

    <b>Don't have an account?</b>
    <br/>
    <a href="CustomerRegister.php">Register Here!</a>
    <br/>  
    <input type="submit" name="btnLogin" value="Login">
    </div>
</div>
</form>
</body>

</html>
